# Project Config Template

> Template para `docs/planning/project-config.md`.
> **Se genera durante:** `/discovery`
> **Se carga en:** `/init`, Phase 1 de todos los workflows

---

## Instrucciones

El agente debe rellenar este template con información del Brief (00_DISCOVERY_BRIEF.md)
y del setup del proyecto. Cada sección tiene instrucciones en comentarios HTML.

---

## Template

````markdown
# Project Config

<!-- INSTRUCCIÓN: No incluir esta línea ni las blockquotes del template en el output -->

---

## 1. Project Info

| Campo                 | Valor                                                        |
| --------------------- | ------------------------------------------------------------ |
| **Nombre**            | {{nombre_proyecto}}                                          |
| **Tipo**              | {{saas-mvp / internal-tool / landing / e-commerce / custom}} |
| **Repo**              | {{org/repo}}                                                 |
| **Branch principal**  | {{main}}                                                     |
| **Branch de trabajo** | {{develop}}                                                  |
| **Idioma UI**         | {{es-MX / en-US}}                                            |
| **Fecha inicio**      | {{fecha}}                                                    |

<!-- INSTRUCCIÓN: No hardcodear versiones. Incluir esta nota solo como recordatorio -->
<!-- Versiones (version, factoryVersion, agentKitVersion) → leer de package.json -->

---

## 2. Problem Statement

<!-- 2-3 líneas: qué hace, para quién, qué problema resuelve -->

{{descripción breve del proyecto}}

---

## 3. Stakeholders

| Rol           | Nombre     | Contacto        | Decides sobre       |
| ------------- | ---------- | --------------- | ------------------- |
| Product Owner | {{nombre}} | {{email/slack}} | Scope, prioridad    |
| Tech Lead     | {{nombre}} | {{email/slack}} | Arquitectura, stack |
| Diseñador     | {{nombre}} | {{email/slack}} | UI/UX               |
| Cliente       | {{nombre}} | {{email/slack}} | Aprobación final    |

<!-- Solo los relevantes para decisiones. Omitir roles sin persona asignada. -->

---

## 4. Tech Stack

> 📦 Versiones exactas → `package.json`

| Capa           | Tecnología                     |
| -------------- | ------------------------------ |
| **Framework**  | {{Next.js (App Router, RSC)}}  |
| **UI**         | {{React}}                      |
| **Styling**    | {{Tailwind CSS v4 + CSS vars}} |
| **Components** | {{shadcn/ui + Radix UI}}       |
| **DB**         | {{Neon Postgres}}              |
| **ORM**        | {{Drizzle ORM}}                |
| **Auth**       | {{Auth.js v5}}                 |
| **Validation** | {{Zod}}                        |

### Stack Overrides (si difiere del SK estándar)

| Componente | SK Estándar | Este Proyecto | Razón |
| ---------- | ----------- | ------------- | ----- |

<!-- Solo si hay diferencias vs el Starter Kit -->

---

## 5. Domain Glossary

<!-- Términos del dominio para que el agente use el vocabulario correcto -->

| Término | Significado | Usar en lugar de |
| ------- | ----------- | ---------------- |

<!-- Ejemplos:
| Partida | Línea de cotización | line item |
| Remisión | Nota de entrega | shipping doc |
| Pool | Grupo de participantes (torneo) | group / league |
-->

---

## 6. External Systems

<!-- Microservicios, APIs, repos, bases de datos externas -->

| Sistema | Tipo | Repo/URL | Conecta con |
| ------- | ---- | -------- | ----------- |

<!-- Ejemplos:
| ERP MySQL | DB externa | 192.168.x.x | Cron de exportación |
| Sports API | REST API | api.sportsdata.io | Data ingestion |
| Mobile App | Flutter | org/mobile-app | Shared API |
-->

---

## 7. Integrations

<!-- Servicios cloud/SaaS que usa este proyecto -->

| Servicio          | Propósito   | Env Var            |
| ----------------- | ----------- | ------------------ |
| {{Resend}}        | {{Email}}   | {{RESEND_API_KEY}} |
| {{Cloudflare R2}} | {{Storage}} | {{R2_*}}           |

---

## 8. Project-Specific Rules

<!-- Reglas únicas de ESTE proyecto que no están en rules/ -->

1. {{Regla específica}}

---

## 9. Quick Commands

```bash
pnpm dev              # Development server
pnpm build            # Production build
pnpm test             # Unit tests (Vitest)
pnpm test:e2e         # E2E tests (Playwright)
pnpm db:generate      # Generate migration
pnpm db:migrate       # Apply migration
```
````

---

> 📝 **Generado:** {{fecha}} | **Versión:** ver `package.json`

_TimeKast Factory — Project Config_

```

---

## Notas para el agente

1. **Rellenar desde Brief:** §1 (proyecto), §2 (stakeholders), §3 (stack), §6 (glossary)
2. **No duplicar:** Features → viven en `features.md`. File structure → vive en `INVENTORY.md`
3. **Mantener corto:** Este archivo debe ser <120 líneas relleno. Es metadata, no documentación.
4. **Actualizar manualmente** si cambia el stack, se agregan integraciones, o cambian stakeholders.
```
