---
description: Patrones Next.js 15 App Router
globs: ['app/**/*.tsx', 'app/**/*.ts']
---

# ⚛️ Reglas Next.js App Router

Aplican a todos los archivos en `app/`.

---

## 🖥️ Server Components por Defecto

```typescript
// ✅ Por defecto: Server Component (sin directiva)
export default async function Page() {
  const data = await fetchData(); // Fetch directo
  return <div>{data}</div>;
}

// ❌ Solo usar 'use client' cuando sea NECESARIO
```

### Cuándo usar `'use client'`

Solo cuando necesites:

- `useState`, `useEffect`, `useReducer`
- Event handlers (`onClick`, `onChange`)
- Browser APIs (`localStorage`, `window`)
- Hooks de terceros que requieren cliente

---

## 🔄 Patrón Server Actions (OBLIGATORIO)

> El SK provee helpers en `lib/actions/helpers.ts` que eliminan boilerplate.
> **Siempre** usar `withAuth()` o `withSelf()` — no escribir auth/validation manual.

```typescript
'use server';

import { withAuth, withSelf } from '@/lib/actions/helpers';

// ✅ Admin action (auth + RBAC + validación + revalidate)
export const createEntity = (input: unknown) =>
  withAuth(
    { resource: 'entities', action: 'create', schema: createEntitySchema, revalidate: '/entities' },
    input,
    async (data, userId) => {
      await db.insert(entities).values({ ...data, createdBy: userId });
    }
  );

// ✅ Self-service action (auth + validación, sin RBAC)
export const updateProfile = (input: unknown) =>
  withSelf({ schema: profileSchema, revalidate: '/profile' }, input, async (data, userId) => {
    await db.update(users).set(data).where(eq(users.id, userId));
  });
```

### ❌ Anti-patrón

```typescript
// ❌ NUNCA — No escribir auth/validation manual
export async function createEntity(formData: FormData) {
  const session = await auth();
  if (!session) return { error: 'No autorizado' };
  // ... boilerplate repetitivo
}
```

---

## 📝 Metadata SEO

Toda página debe exportar metadata:

```typescript
// app/dashboard/page.tsx
export const metadata: Metadata = {
  title: 'Dashboard | App Name',
  description: 'Panel principal de la aplicación',
};
```

---

## 📁 Estructura de Archivos

```
app/
  ├── (auth)/          # Grupo: páginas públicas
  │   ├── login/
  │   └── register/
  ├── (protected)/     # Grupo: páginas protegidas
  │   ├── dashboard/
  │   └── settings/
  ├── api/             # API Routes (solo si necesario)
  ├── layout.tsx       # Layout raíz
  └── page.tsx         # Página principal
```

---

## 🎨 Estados UI Obligatorios

Toda página/componente que carga datos debe manejar:

| Estado  | Implementación                            |
| ------- | ----------------------------------------- |
| Loading | `loading.tsx` o `<Suspense>` con Skeleton |
| Empty   | Mensaje + CTA si aplica                   |
| Error   | `error.tsx` + mensaje claro + retry       |
| Success | Render normal de datos                    |

---

## 📱 Responsive Obligatorio

- Mobile-first: diseñar para 375px primero
- Breakpoints: `sm:640` `md:768` `lg:1024` `xl:1280`
- **NO scroll horizontal** en ningún viewport
- Touch targets: mínimo 44x44px
- Input font-size: ≥16px (evita zoom en iOS)

---

## ❌ Anti-patrones

| ❌ No hacer                     | ✅ Hacer                    |
| ------------------------------- | --------------------------- |
| Fetch en Client Components      | Server Components + Actions |
| Lógica de negocio en `page.tsx` | Extraer a actions/utils     |
| `console.log` en producción     | Logger o eliminar           |
| CSS inline extenso              | Tailwind classes            |
