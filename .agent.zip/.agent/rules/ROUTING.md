---
trigger: always_on
---

# 🗺️ Agent Routing & File Awareness

> Reglas de routing y awareness de dependencias.
> **Ubicación:** `.agent/rules/ROUTING.md`

---

## 🤖 Auto-Routing de Agentes

> Detectar automáticamente qué agente cargar según keywords en el request.
>
> 🎯 **Keywords SSOT:** `.agent/registry/registry.yaml` §agents (29 agents con keywords bilingual)
>
> Para ver la tabla completa: `.agent/registry/views/agents.md`

### Protocolo

1. **Analizar:** Detectar keywords (EN/ES) del request del usuario
2. **Consultar:** Matchear contra `registry.yaml` §agents → `keywords_any` + `keywords_es`
3. **Seleccionar:** Aplicar scoring: keyword match × priority × domain relevance
4. **Precedencia:** `explicit_user_mention > issue_field > keyword_match > workflow_default > fallback`
5. **Caps:** máx 3 agents por issue

**Formato de anuncio (OBLIGATORIO — agents Y skills):**

```markdown
🤖 Aplicando conocimiento de `@{agent-name}`...
🧰 Skills: `{skill-1}`, `{skill-2}`
```

---

## 📁 File Dependency Awareness

> Ver `GEMINI.md` § TIER 0 → File Dependency Awareness para las reglas completas.

---

_TimeKast Factory — Routing & File Awareness_
