---
trigger: always_on
---

# HIERARCHY — TimeKast Factory

> Jerarquía de autoridad para resolución de conflictos.
> **Ubicación:** `.agent/rules/HIERARCHY.md`

---

## 1. Autoridad de Documentos

> En caso de conflicto, el documento de nivel superior manda.

| Nivel | Path                        | Propósito                                 |
| ----- | --------------------------- | ----------------------------------------- |
| 1     | `rules/GEMINI.md`           | Meta-rules del kit (Socratic Gate, Tiers) |
| 2     | `rules/00-03_*.mdc`         | Reglas técnicas por stack                 |
| 3     | `rules/04_complementary.md` | Reglas complementarias Factory            |
| 4     | `rules/ROUTING.md`          | Routing de agentes, file awareness        |
| 4.5   | `registry/registry.yaml`    | SSOT de agents, skills, combos, fallbacks |
| 5     | `skills/domains/*`          | Reglas por stack (ui, db, api, security)  |
| 6     | `skills/roles/*`            | Comportamientos por flujo                 |
| 7     | `workflows/*`               | Flujos de trabajo ejecutables             |
| 8     | `docs/planning/*`           | Documentación del proyecto                |
| 9     | `docs/backlog/*`            | Issues y epics                            |

---

## 2. Prioridad de Skills

| Tier | Path       | SSOT Para            | Prioridad |
| ---- | ---------- | -------------------- | --------- |
| P1   | `roles/`   | QUÉ hacer, CUÁNDO    | Mayor     |
| P2   | `domains/` | CÓMO en ESTE stack   | Media     |
| P3   | (kit root) | POR QUÉ (principios) | Menor     |

### Regla de Conflicto

```
Si domains/ui/ dice "usar solo clases de Tailwind"
y frontend-design/ sugiere valores arbitrarios
→ domains/ui/ GANA (es SSOT del stack)
```

---

## 3. SSOT Chain

```
Discovery → Proposal → Docs → Design → Backlog → Code
```

| Fase      | Documento                             | SSOT para                |
| --------- | ------------------------------------- | ------------------------ |
| Discovery | `docs/planning/00_DISCOVERY_BRIEF.md` | Requisitos, scope        |
| Proposal  | `docs/planning/01_PROPOSAL.md`        | Oferta al cliente        |
| Docs      | `docs/planning/02-14_*.md`            | Personas, US, BR, Data   |
| Design    | `docs/planning/15_DESIGN.md`          | Pantallas, flujos, comps |
| Backlog   | `docs/backlog/*/issues/*.md`          | Issues ejecutables       |
| Code      | `lib/db/schema/*.ts`                  | Schema de DB             |

---

## 4. Cuándo Cargar Cada Tier

| Workflow     | roles/     | domains/     | kit skills       |
| ------------ | ---------- | ------------ | ---------------- |
| `/design`    | design/    | ui/          | frontend-design/ |
| `/implement` | implement/ | Por keywords | Según necesidad  |
| `/docs`      | docs/      | db/          | —                |
| `/backlog`   | backlog/   | —            | —                |

---

## 5. Regla de Oro

> **Skills y workflows NUNCA redefinen reglas.**
> Solo ejecutan y aplican lo que dicen las rules.

Si necesitas cambiar una regla:

1. Modifica el archivo correspondiente en `rules/`
2. Skills/workflows lo heredan automáticamente

---

_TimeKast Factory — Document & Skills Hierarchy_
