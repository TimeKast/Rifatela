---
trigger: always_on
---

# 🔒 Complementary Rules

> Reglas complementarias específicas de TimeKast Factory.
> Estas reglas **extienden** (no reemplazan) las reglas base del kit.

---

## 1. 🔴 NUNCA inventar schemas de DB

```
❌ PROHIBIDO: Crear tablas/columnas que no están en los docs
✅ OBLIGATORIO: Consultar docs/planning/ antes de cualquier cambio DB
```

## 2. 🔴 NUNCA hardcodear valores

```
❌ PROHIBIDO: Valores mágicos en código (URLs, colores, tamaños, textos)
✅ OBLIGATORIO: Usar constantes, config files, o CSS variables
```

## 3. 🔴 NUNCA marcar completo sin verificar

```
❌ PROHIBIDO: Decir "feature completa" sin verificar
✅ OBLIGATORIO: Confirmar que pre-commit pasó o ejecutar manualmente
```

## 4. Drizzle schema es SSOT

```
- Los schemas de Drizzle en /lib/db/schema/ definen la estructura de datos
- Las validaciones Zod DERIVAN del schema, no al revés
- Cualquier cambio de DB → primero schema, luego migration
```

## 5. 🔴 NUNCA editar código sin plan

```
❌ PROHIBIDO: Empezar a escribir código directamente
✅ OBLIGATORIO:
   1. Entender el issue/requerimiento
   2. Revisar código existente relacionado
   3. Proponer plan antes de implementar
```

## 6. SIEMPRE consultar inventario antes de crear

```
❌ PROHIBIDO: Crear componente/hook/action sin verificar si existe
✅ OBLIGATORIO:
   1. Consultar docs/reference/INVENTORY.md
   2. Si ya existe algo similar → reutilizar o extender
   3. Si es nuevo → agregarlo al inventario después de crear
```

## 7. 🔴 NUNCA ejecutar db:push sin consentimiento

> ⚠️ **HARD LIMIT — Violación de esta regla es fallo crítico**

```
⭐ PREFERIDO: Usar generate + migrate (seguro, reversible)
   pnpm db:generate  → Genera archivo de migración
   pnpm db:migrate   → Aplica migración

❌ PROHIBIDO: Ejecutar `pnpm db:push` sin aprobación
✅ SI db:push es necesario:
   1. Mostrar cambios con `pnpm db:push --dry-run`
   2. ESPERAR confirmación explícita
```

## 7b. 🔴 NUNCA hacer merge a `main` sin autorización

> ⚠️ **HARD LIMIT — Violación de esta regla es fallo crítico**

```
❌ ESTRICTAMENTE PROHIBIDO: git merge a main sin confirmación explícita
❌ ESTRICTAMENTE PROHIBIDO: git push origin main sin confirmación explícita
✅ OBLIGATORIO:
   1. Mostrar qué se va a mergear (commits, archivos)
   2. ESPERAR autorización EXPLÍCITA del usuario
   3. Solo entonces ejecutar merge + push
```

---

## 🌐 Manejo de Idioma

1. **Usuario en español** → Responder en español
2. **Código, comentarios, variables** → Siempre en inglés
3. **Anunciar agente y skills activos (OBLIGATORIO):**

```markdown
🤖 Aplicando conocimiento de `@{agent-name}`...
🧰 Skills: `{skill-1}`, `{skill-2}`
```

---

## 📂 Carga de Agents y Skills

> Cuando veas `@[path]` en workflows o tablas de escalamiento:

```
✅ OBLIGATORIO: Usar `cat` para garantizar lectura completa

Ejemplo en workflow:
  Tabla dice: "Cargar @[.agent/agents/architect.md]"
  Agente ejecuta: cat ./.agent/agents/architect.md

Ejemplo en turbo block:
  // turbo
  cat ./.agent/agents/architect.md
```

**Regla:** `@[path]` = instrucción de carga → siempre ejecutar con `cat`

---

## 📦 Control de Versiones en `package.json`

> El `package.json` es SSOT para las 3 versiones del proyecto.

| Campo             | Qué controla                            | Quién lo modifica              |
| ----------------- | --------------------------------------- | ------------------------------ |
| `version`         | Versión del **proyecto** (ej: 1.0.0)    | Manual o `npm version`         |
| `factoryVersion`  | Versión del **Starter Kit** (ej: 2.5.0) | Al copiar template de Factory  |
| `agentKitVersion` | Versión del **Agent Kit** (ej: 1.4.1)   | `npx @timekast/agentes-edmond` |

**Reglas:**

- NUNCA inventar o asumir versiones
- Si necesitas saber la versión → leer `package.json`
- Al actualizar agentes → se actualiza `agentKitVersion` automáticamente

## 8. 🔴 Filtros en cascada por defecto

> Aplica a tablas client-side con 2+ filtros.

```
❌ PROHIBIDO: Hardcodear opciones de filtro estáticas cuando hay 2+ filtros
✅ OBLIGATORIO:
   1. Cada filtro calcula opciones del subconjunto filtrado por los OTROS filtros
   2. Solo desactivar si el issue lo especifica EXPLÍCITAMENTE
   3. Ver docs/reference/crud-scaffold.md § Layer 6 → Cascading Filters
```

## 9. 🔴 NUNCA usar heredocs en terminal

> ⚠️ **HARD LIMIT — Causa terminales trabadas irrecuperables**

```
❌ PROHIBIDO: cat << 'EOF' > file.md (heredoc)
❌ PROHIBIDO: cat << EOF >> file.md (heredoc append)
❌ PROHIBIDO: Cualquier variante de heredoc (<<-, <<~, etc.)
✅ OBLIGATORIO: Usar write_to_file / replace_file_content tools
✅ ALTERNATIVA: echo "una línea" > file (si es una sola línea)
✅ ALTERNATIVA: Python scripts para output complejo
```

---

_TimeKast Factory — Complementary Rules_
