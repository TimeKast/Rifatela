# Phase 1: Context Loading

> **Propósito:** Cargar knowledge base, agentes, y docs de referencia del SK.
> **Se ejecuta SIEMPRE** — tanto en full como en add mode.

---

## 1.1 Load Knowledge Base

// turbo

```bash
cat ./.agent/skills/roles/backlog/SKILL.md
```

// turbo

```bash
cat ./.agent/rules/DOR_DOD.md 2>/dev/null || echo "No DOR_DOD.md"
```

// turbo

```bash
cat ./docs/planning/project-config.md 2>/dev/null || echo "No project-config.md"
```

---

## 1.2 Previous Validation Report (if exists)

// turbo

```bash
PREV_REPORT=$(ls docs/reports/validation_design_*.md 2>/dev/null | head -1)
[ -n "$PREV_REPORT" ] && { echo "📋 Loading: $PREV_REPORT"; cat "$PREV_REPORT"; } || echo "📝 No previous validation report"
```

---

## 1.3 SK Docs (Guides + References)

> 🎯 **El SK ya tiene mucho implementado** — cargar estos docs evita crear issues redundantes.
> Incluye `crud-scaffold.md` para estandarizar issues de CRUD.

// turbo

```bash
echo "📚 Loading Starter Kit Guides..."
for guide in ./docs/guides/*.md; do
  BASENAME=$(basename "$guide")
  # Skip: SKILL already covers getting-started; troubleshooting not relevant for issues
  [ "$BASENAME" = "getting-started.md" ] && continue
  [ "$BASENAME" = "troubleshooting.md" ] && continue
  if [ -f "$guide" ]; then
    echo "--- $BASENAME ---"
    cat "$guide"
  fi
done
```

// turbo

```bash
echo "📖 Loading Reference Docs..."
for ref in ./docs/reference/*.md; do
  BASENAME=$(basename "$ref")
  if [ -f "$ref" ]; then
    echo "--- $BASENAME ---"
    if [ "$BASENAME" = "CODEBASE.md" ]; then
      head -30 "$ref"  # TOC only — full file too heavy for backlog context
    else
      cat "$ref"
    fi
  fi
done
```

> ⚠️ **CONTEXT WARNING**
>
> Este workflow carga mucho contexto (~50-70% del límite).
> Para mejores resultados:
>
> 1. Ejecutar en un **chat nuevo** dedicado
> 2. Comenzar con `/init` → `/backlog`

---

## 1.4 Agents

> 🤖 **Agentes para backlog**

// turbo

```bash
cat ./.agent/agents/project-planner.md
```

// turbo

```bash
head -80 ./.agent/agents/architect.md
```

---

_Phase 1 Complete → Continuar a Phase 2 (Prerequisites) o Phase 3 (en add mode)_
