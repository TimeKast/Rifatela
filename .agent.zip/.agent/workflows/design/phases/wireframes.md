# Phase 4: Wireframes Textuales

> **Propósito:** Generar wireframes ASCII de TODAS las pantallas SCR-XXX como §9 de `15_DESIGN.md`.
> **Trigger:** Después de Phase 2-3 (Generation), antes de Phase 4 (Validation).

---

## 3.5.1 Scope

> 🔴 **OBLIGATORIO:** Cada pantalla SCR-XXX documentada en §1 del design DEBE tener un wireframe.

**Input:** Pantallas ya generadas en §1-§5 de `15_DESIGN.md`.
**Output:** Sección §9 agregada al final de `15_DESIGN.md`.

---

## 3.5.2 Formato por Wireframe

Cada wireframe DEBE incluir estos 4 elementos:

### 1. Layout ASCII

```
### SCR-XXX: {Nombre de Pantalla}

┌─────────────────────────────┐
│         [Header]            │
│                             │
│  {Elementos principales}    │
│  del layout con cajas       │
│  ASCII representando los    │
│  componentes reales         │
│                             │
│       [   CTA   ]           │
│                             │
└─────────────────────────────┘
```

### 2. Nota Mobile

```
- Mobile: {Cómo cambia el layout en viewport < 768px}
```

### 3. States

```
- States: {loading, empty, error, data — los que apliquen}
```

### 4. RBAC

```
- RBAC: {Roles que acceden a esta pantalla, o "público"}
```

---

## 3.5.3 Template de §9

Agregar al final de `15_DESIGN.md`:

```markdown
---

## §9: Wireframes Textuales

> Representación ASCII de cada pantalla para referencia rápida en `/backlog` y `/implement`.

### SCR-001: {Nombre}

┌─────────────────────────────┐
│ [Logo/Header] │
│ │
│ {Layout del contenido} │
│ │
└─────────────────────────────┘

- Mobile: {adaptación responsive}
- States: {loading, empty, error, data}
- RBAC: {roles con acceso}

### SCR-002: {Nombre}

{... mismo formato ...}
```

---

## 3.5.4 Reglas

**SIEMPRE:**

1. Un wireframe por cada SCR-XXX listada en §1
2. Usar box-drawing characters (`┌ ─ ┐ │ └ ┘`) para consistencia
3. Incluir los 4 elementos (layout, mobile, states, RBAC)
4. Referenciar componentes SK y CMP-XXX dentro del wireframe
5. Mantener el wireframe simple — es referencia rápida, no mockup completo

**NUNCA:**

1. Omitir pantallas que están en §1
2. Crear wireframes sin nota de mobile
3. Generar imágenes en lugar de texto
4. Poner wireframes en archivo separado (siempre §9 de `15_DESIGN.md`)

---

## 3.5.5 Verificación

Antes de pasar a Phase 4 (Validation):

```bash
# Contar pantallas en §1 vs wireframes en §9
SCREENS=$(grep -c "^### SCR-" docs/planning/15_DESIGN.md | head -1)
WIREFRAMES=$(grep -c "^### SCR-" docs/planning/15_DESIGN.md | tail -1)
echo "Pantallas: $SCREENS | Wireframes: $WIREFRAMES"
```

Si hay discrepancia → Completar wireframes faltantes antes de continuar.

---

_TimeKast Factory — Design Wireframes Phase_
