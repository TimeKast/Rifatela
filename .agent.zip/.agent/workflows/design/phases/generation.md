# Phase 3: Generation (3-Pass)

> **Carga:** Después de CHECKPOINT 1 aprobado
>
> **Estrategia:** Generar en 3 pasadas para evitar output truncation.
> Cada pasada produce ~25KB. CPs intermedios verifican cobertura.

---

## 3.1: Verify Mode (Refresh vs Generate)

```bash
# Si archivo existe, estamos en modo REFRESH
if [ -f "./docs/planning/15_DESIGN.md" ]; then
  echo "⚠️ Modo REFRESH: preservar IDs SCR/FLW/CMP/DD existentes"
else
  echo "✅ Modo GENERATE: crear desde template"
fi
```

**Regla de refresh:**

- Si 15_DESIGN.md ya existe → preservar IDs asignados
- Solo agregar/modificar contenido, no reordenar
- Nuevos items reciben siguiente ID disponible

---

## 3.2: Create File (solo si no existe)

```bash
mkdir -p ./docs/planning
[ ! -f ./docs/planning/15_DESIGN.md ] && cp ./.agent/skills/roles/design/15_DESIGN.template.md ./docs/planning/15_DESIGN.md
```

---

## 3.3: Starter Kit Awareness (MANDATORY)

> 🔴 **ANTES de diseñar, verificar qué ya existe en INVENTORY.md y CODEBASE.md.**
>
> Estos archivos se cargaron en Phase 1 (context-loading.md).

**REGLA:** Para cada pantalla/componente a diseñar:

| Ya existe en INVENTORY/CODEBASE? | Acción                                           |
| -------------------------------- | ------------------------------------------------ |
| ✅ Existe completo               | Marcar `🏗️ SK Provided` — NO rediseñar           |
| 🟡 Existe parcial                | Marcar `🔧 SK Extended` — diseñar solo extensión |
| ❌ No existe                     | Diseñar completo como `🆕 New`                   |

---

## 3.3.5: Design Tokens (MANDATORY)

> 🔴 **OBLIGATORIO:** Leer tokens existentes del SK y documentar en 15_DESIGN.md.

// turbo

```bash
cat ./src/app/globals.css 2>/dev/null | head -100 || echo "No globals.css"
```

// turbo

```bash
cat ./tailwind.config.ts 2>/dev/null | head -80 || echo "No tailwind.config.ts"
```

**Instrucciones:**

1. **Documentar** en 15_DESIGN.md sección "Design Tokens":
   - Paleta de colores (SK base ± cambios del proyecto)
   - Typography scale (fuentes, tamaños)
   - Spacing system (valores base)
   - Breakpoints (responsive)

2. **Si Discovery §4 indica cambio de branding** → definir nuevos tokens aquí

3. **Marcar origen:**
   - `🏗️ SK Default` — usar tokens existentes del SK
   - `🎨 Custom` — tokens modificados para este proyecto

---

## 3.4: Kit Skills Consultation (Design Enhancement)

> 🎨 **Durante la generación, consultar skills del Kit:**

| Decisión                  | Consultar                                  |
| ------------------------- | ------------------------------------------ |
| Color palette, contrast   | `kit/frontend-design/color-system.md`      |
| Typography scale, pairing | `kit/frontend-design/typography-system.md` |
| UX laws (Hick's, Fitts')  | `kit/frontend-design/ux-psychology.md`     |
| Touch targets, gestures   | `kit/mobile-design/touch-psychology.md`    |
| Animations, transitions   | `kit/frontend-design/animation-guide.md`   |

**Prioridad:** `domains/ui/ (Stack SK) > kit/ (Principios)`

---

## 3.5: Architect Gating

**Cargar `@[.agent/agents/architect.md]` si encuentras:**

| Situación            | Impacto                      |
| -------------------- | ---------------------------- |
| Offline-first UI     | Cache strategy, sync         |
| Realtime features    | WebSockets vs polling        |
| Complex state        | Global state patterns        |
| Performance-critical | Virtualization, lazy loading |
| Multi-step wizards   | State persistence            |

---

## ═══════════════════════════════════════

## PASADA 1: Visual Direction + Structure

## ═══════════════════════════════════════

> **Output:** §0 Visual Direction, §1 Mapa de Pantallas, §2 Navegación, §3 Flujos Principales

**Generar las siguientes secciones de 15_DESIGN.md:**

| Sección               | Contenido                                                        | IDs     |
| --------------------- | ---------------------------------------------------------------- | ------- |
| §0 Visual Direction   | Paleta, tipografía, icons, shell, motion, density, anti-patterns | —       |
| §1 Mapa de Pantallas  | URL, propósito, acceso por rol, **FT-XXX**                       | SCR-XXX |
| §2 Navegación         | Mobile tabs, desktop sidebar, RBAC nav                           | —       |
| §3 Flujos Principales | Mermaid diagrams, states, errors                                 | FLW-XXX |

**Para §1 — Cross-reference por pantalla:**

| Campo                | Obligatorio | Ejemplo        |
| -------------------- | ----------- | -------------- |
| `Features: FT-XXX`   | ✅          | FT-002, FT-007 |
| `Implementa: US-XXX` | ✅          | US-010, US-013 |
| `Acceso: P-XXX`      | ✅          | P-003 (Host)   |
| `Valida: BR-XXX`     | si aplica   | BR-012         |
| `Data: E-XXX`        | si aplica   | E-001 (users)  |

**Scope Notes (OBLIGATORIO para pantallas delgadas):**

Si una pantalla cubre un feature de manera parcial o simplificada
respecto al Brief, documentar un campo `Scope Note`:

```
Scope Note: MVP solo browse + join. Filtros/search diferidos a v1.1.
```

- **Propósito:** Diferenciar poda consciente (documentada) de omisión accidental (gap)
- **Aplica cuando:** El Brief o Feature Map describe más funcionalidad
  de la que el design implementa para esa pantalla

### 🔴 Checkpoint Intermedio 1 (dentro del chat, NO notify_user)

Al terminar Pasada 1, mostrar al usuario:

```markdown
## ✅ Pasada 1 Completada

**Visual Direction:** [resumen 1 línea]
**Pantallas:** SCR-001 → SCR-XXX ([N] total)
**Flujos:** FLW-001 → FLW-XXX ([M] total)
**Coverage vs Brief §7.2:** [N/total] pantallas cubiertas

¿Continuar con Pasada 2 (Componentes + Decisions)?
```

**Esperar confirmación antes de Pasada 2.**

---

## ═══════════════════════════════════════

## PASADA 2: Components + Decisions

## ═══════════════════════════════════════

> **Output:** §4 Componentes por Pantalla, §5 Data Requirements, §6 Decisions, §7 OQ, §8 Assumptions

**Generar las siguientes secciones de 15_DESIGN.md:**

| Sección           | Contenido                                           | IDs          |
| ----------------- | --------------------------------------------------- | ------------ |
| §4 Componentes    | SK usados + nuevos + interaction states             | CMP-XXX      |
| §5 Data Req       | §5.0 Cache model + lifecycle, tabla mutations       | —            |
| §6 Decisions      | Opciones + elegida + razón + **Data Impact**        | DD-XXX       |
| §7 Open Questions | Heredar Brief §7 + clasificar arch/product/cosmetic | OQ-XXX       |
| §8 Assumptions    | §8.1 Supuestos, §8.2 **Deferred to Backlog**        | A-XXX, D-XXX |

**Para §4 — por cada SCR, especificar:**

1. Componentes SK a usar (con variantes si aplica)
2. Componentes nuevos a crear (con `CMP-XXX`)
3. Estados de la pantalla (loading, empty, error, data)
4. **Surface hierarchy** (base → card → input depth levels)
5. **Interaction states** para componentes interactivos:

| Componente | Default | Hover | Selected | Disabled |
| ---------- | ------- | ----- | -------- | -------- |

> Solo para componentes interactivos (cards, toggles, selectores, rows).
> No para texto estático o labels.

> 🔴 **Anti-duplicación:** Verificar `features.md` antes de crear CMP-XXX.

**Para §5 — obligatorio:**

1. **§5.0 Cache model (narrativa antes de tabla):**
   - ¿Cuáles son los eventos de invalidación del sistema?
   - ¿Cuándo se usa polling y por qué?
   - ¿Cuándo es static y qué lo cambia?
   - ¿Hay un modelo push (websocket/SSE) o es todo pull?

2. **Mutation lifecycle por pantalla con mutations:**
   - ¿Qué estado intermedio existe? (draft, pending, confirmed)
   - ¿Qué mutation usa cada acción del usuario?
   - ¿Cuándo se snapshotea/audita?
   - ¿Qué pasa si el usuario abandona a mitad?

3. **Tabla de mutations con lifecycle:**

| SCR | Mutation | Trigger | Pre-state | Post-state | Invalidates |
| --- | -------- | ------- | --------- | ---------- | ----------- |

**Para §6 — cada DD DEBE tener:**

| DD  | Decisión | Opciones | Elegida | Razón | Data Impact |
| --- | -------- | -------- | ------- | ----- | ----------- |

**Data Impact (obligatorio si afecta data):**

- Qué mutations/queries cambian según la opción elegida
- Qué estado intermedio existe (draft, pending, etc.)
- Qué se invalida/revalida al ejecutar

**Para §7 — Open Questions:**

🔴 **Herencia obligatoria de Brief:**

1. Leer `00_DISCOVERY_BRIEF.md` §7 (preguntas abiertas / riesgos)
2. Para cada pregunta del Brief con impacto en UI/UX → heredar a §7
3. Si ya fue resuelta por una DD → documentar como "Resuelta: DD-XXX"

**Clasificación obligatoria:**

| Categoría       | Definición                                       | Ejemplo              |
| --------------- | ------------------------------------------------ | -------------------- |
| `architectural` | Impacta modelo de datos, cache, real-time, state | Real-time vs polling |
| `product`       | Impacta scope, funcionalidad, roles              | ¿Playoffs en MVP?    |
| `cosmetic`      | Solo apariencia, no funcionalidad                | ¿Logo SVG o PNG?     |

**Mínimos:** Al menos 1 `architectural` + 1 `product` (si Brief §7 los tiene).

**Para §8 — Assumptions + Deferred:**

### §8.1: Design Assumptions

| A-XX | Supuesto | Si es incorrecto |

### §8.2: Deferred to Backlog

| D-XX | Ambigüedad | Pantalla | Impacto |

> Temas que conscientemente NO se resuelven en design,
> se dejan para resolver en issues de backlog.

### 🔴 Checkpoint Intermedio 2 (dentro del chat, NO notify_user)

```markdown
## ✅ Pasada 2 Completada

**Componentes nuevos:** CMP-001 → CMP-XXX ([K] total)
**Decisions:** DD-001 → DD-XXX ([D] total)
**Open Questions:** [N]
**Assumptions:** [N]

¿Continuar con Pasada 3 (Wireframes)?
```

**Esperar confirmación antes de Pasada 3.**

---

## ═══════════════════════════════════════

## PASADA 3: Wireframes

## ═══════════════════════════════════════

> **Output:** §9 Wireframes Textuales
>
> **§10 Checklist se genera DESPUÉS de Phase 5 (Validation fixes).**

**§9 Wireframes — por cada SCR, generar:**

```
┌──────────────────────────────────┐
│ [Header / Nav]                   │
├──────────────────────────────────┤
│                                  │
│  [Main Content Area]             │
│                                  │
│  [Components + Layout]           │
│                                  │
├──────────────────────────────────┤
│ [Footer / Bottom Nav]            │
└──────────────────────────────────┘
```

---

## 3.6: Validación Automática (grep checks)

// turbo

```bash
# Verificar SCR IDs
grep -qE "SCR-[0-9]{3}" ./docs/planning/15_DESIGN.md && echo "✅ Screens present" || echo "❌ Missing SCR IDs"
```

// turbo

```bash
# Verificar FLW IDs y Mermaid
grep -qE "FLW-[0-9]{3}" ./docs/planning/15_DESIGN.md && echo "✅ Flows present" || echo "❌ Missing FLW IDs"
grep -q "\`\`\`mermaid" ./docs/planning/15_DESIGN.md && echo "✅ Mermaid present" || echo "❌ Missing Mermaid diagrams"
```

// turbo

```bash
# Verificar OQ y Assumptions
grep -q "## Open Questions" ./docs/planning/15_DESIGN.md && echo "✅ Open Questions" || echo "❌ Missing OQ"
grep -q "## Assumptions" ./docs/planning/15_DESIGN.md && echo "✅ Assumptions" || echo "❌ Missing Assumptions"
```

---

_Phase 3 Complete → Continuar a Phase 4 (Wireframes) o CHECKPOINT 2_
