---
description: Docs workflow - generate technical documentation from discovery
---

# /docs — Technical Documentation

> **Flujo:** Bootstrap (Fase 2 — Documentación)
> **Anterior:** `/proposal`
> **Siguiente:** `/validate_docs` → `/design`
> **Propósito:** Generar documentación técnica central (02-14) desde Discovery Brief.

---

## Hard Gates

| Validación              | Si falla                        |
| ----------------------- | ------------------------------- |
| Discovery Brief existe  | ❌ STOP — Ejecutar `/discovery` |
| §1, §2, §3, §6 están ✅ | ❌ STOP — Completar discovery   |

---

## Phase 0: Mode Detection + Context Status

// turbo

```bash
cat ./.agent/workflows/docs/phases/context.md
```

---

## Phase 1: Context Loading

// turbo

```bash
cat ./.agent/workflows/docs/phases/context-loading.md
```

---

## Phase 2: Prerequisites

// turbo

```bash
cat ./.agent/workflows/docs/phases/prerequisites.md
```

---

## 🛑 CHECKPOINT 1: Pre-Generation

> ⚠️ **MANDATORY STOP — USAR notify_user TOOL**

**EL AGENTE DEBE:**

0. **Anunciar agents y skills activos (OBLIGATORIO, UNA VEZ):**

   ```
   🤖 Kit: @documentation-writer, @architect
   🧰 Kit Skills: roles/docs, documentation-templates, architecture, plan-writing
   🏗️ Project: @{project-agents} (si se cargaron en Phase 1 §1.8)
   🧰 Project Skills: {project-skills} (si se cargaron en Phase 1 §1.8)
   ```

   > Si no hay project agents/skills, omitir las líneas de Project.

1. Mostrar resumen:

- Coverage Map: §1, §2, §3, §6 = ✅
- Templates: Listos ✅
- Docs a generar: 02-14

**ACTION:** Call `notify_user` with `BlockedOnUser: true`

🛑 **STOP AQUÍ — NO continuar sin respuesta del usuario.**

---

## Phase 3: Generate Core Docs (02-09)

> ⚠️ **SOLO DESPUÉS DE CHECKPOINT 1 APROBADO**

// turbo

```bash
cat ./.agent/workflows/docs/phases/generation.md
```

---

## Phase 4: Generate Extended Docs (10-14)

// turbo

```bash
cat ./.agent/workflows/docs/phases/extended-docs.md
```

---

## 🛑 CHECKPOINT 2: Post-Generation Review

> 🔴 **HARD GATE — El agente DEBE parar aquí.**

**EL AGENTE DEBE:**

1. Mostrar resumen de documentación generada:
   - Documentos: [lista de 02-14 generados]
   - Entidades (06_DATA_MODEL): [N] E-XXX
   - Features (02_FEATURE_MAP): [N] FT-XXX
   - Reglas (05_BUSINESS_RULES): [N] BR-XXX

2. Anunciar validaciones pendientes:
   - 🔲 Namespace consistency (BR- not RN-)
   - 🔲 Source Reconciliation vs Brief (entidades, features, reglas, pantallas)
   - 🔲 Internal cross-reference check
   - 🔲 Multi-Agent Review (5 perspectivas)
   - 🔲 Validation Report

3. Mostrar opciones:

   | #   | Opción    | Acción                    |
   | --- | --------- | ------------------------- |
   | 1   | validar   | Proceder con validaciones |
   | 2   | revisar   | Ver documentos generados  |
   | 3   | regenerar | Volver a generar          |

4. **ACTION:** Call `notify_user` con `BlockedOnUser: true`, `ShouldAutoProceed: false`

🛑 **STOP — NO ejecutar validaciones sin aprobación.**

---

## Phase 5: Validation & Gap Analysis

> ⚠️ **SOLO DESPUÉS DE CHECKPOINT 2 APROBADO**

// turbo

```bash
cat ./.agent/workflows/docs/phases/validation.md
```

---

## 🛑 CHECKPOINT 3: Pre-Close Review

> 🔴 **HARD GATE — STOP ABSOLUTO**
>
> **VIOLACIÓN DE ESTA REGLA = FALLO CRÍTICO**

**EL AGENTE DEBE:**

1. Mostrar análisis de cobertura:
   - Cobertura vs Discovery: [X%]
   - Cobertura vs Proposal: [Y%]
   - Gaps críticos: [N]
   - Drift detectado: [M]

2. Mostrar opciones:

   | #   | Opción   | Acción                            |
   | --- | -------- | --------------------------------- |
   | 1   | corregir | Fix gaps                          |
   | 2   | revisar  | Ver docs                          |
   | 3   | validar  | Ejecutar `/validate_docs` primero |
   | 4   | aprobar  | Continuar a /design               |

3. **ACTION:** Call `notify_user` with `BlockedOnUser: true`
4. **NO ejecutar NINGUNA acción posterior**
5. **Esperar respuesta explícita del usuario**

**VERIFICACIÓN DE FALLO:**

- Si el agente continúa sin respuesta → **FALLO**
- Si no usó `notify_user` → **FALLO**

🛑 **STOP AQUÍ — NO continuar sin aprobación.**

---

## Phase 6: Handoff

> ⚠️ **SOLO DESPUÉS DE CHECKPOINT 3 APROBADO**

// turbo

```bash
cat ./.agent/workflows/docs/phases/close.md
```

---

## Reglas SIEMPRE/NUNCA

**SIEMPRE:**

1. Context Status (Phase 0) primero
2. Verificar Coverage Map antes de generar
3. CHECKPOINT 1 antes de generar
4. CHECKPOINT 2 después de generar (resumen + validaciones pendientes)
5. Drift/Gap analysis antes de CHECKPOINT 3
6. CHECKPOINT 3 antes de handoff

**NUNCA:**

1. Generar sin CHECKPOINT 1 aprobado
2. Cerrar sin CHECKPOINT 3 aprobado
3. Inventar aprobación del usuario
4. Saltar validation/gap analysis

---

_TimeKast Factory — Docs Workflow (v3 — Refactored)_
