# Phase 4: Generate Extended Docs (3-Batch)

> **Carga:** Después de Phase 3 (core docs 02-05 + 09)
>
> **Estrategia:** Generar en 3 batches para evitar context degradation.
> Batch 4 (Technical: Arch+DM) → Batch 5 (API) → Batch 6 (Operational).

---

## Doc Catalog (Extended — Phase 4)

| #   | Documento     | Contenido                         | SSOT              | Batch |
| --- | ------------- | --------------------------------- | ----------------- | ----- |
| 07  | ARCHITECTURE  | Stack decisions, ADRs             | Código + ADRs     | 4     |
| 06  | DATA_MODEL    | Schema Drizzle, relaciones        | `lib/db/schema/*` | 4     |
| 08  | API_CONTRACTS | Server Actions, I/O, Errors       | Este doc + código | 5     |
| 10  | RUNBOOKS      | Procedimientos operacionales      | Este doc          | 6     |
| 11  | TEST_STRATEGY | Pirámide de tests, coverage goals | Este doc          | 6     |
| 12  | E2E_SCENARIOS | Flujos críticos para Playwright   | Este doc          | 6     |
| 13  | RISK_REGISTER | Riesgos × Impacto × Mitigación    | Este doc          | 6     |
| 14  | TRACEABILITY  | US→Issue→Test→Deploy mapping      | Este doc          | 6     |

---

## ═══════════════════════════════════════

## BATCH 4: Technical — Architecture + Data Model (07 + 06)

## ═══════════════════════════════════════

> **Output:** 07_ARCHITECTURE, 06_DATA_MODEL
>
> **Depende de:** Batches 2-3 (04_USER_STORIES + 05_BUSINESS_RULES)
>
> ⚠️ **Orden crítico:** 07 se genera ANTES que 06 para que las ADRs
> informen decisiones del Data Model (ej: cardinalidad, jerarquías, SSOT patterns).

### Load DB Patterns

// turbo

```bash
# DB patterns para 06_DATA_MODEL (Drizzle, schema, migrations)
cat ./.agent/skills/domains/db/SKILL.md 2>/dev/null | head -100 || echo "No domains/db skill"
```

### Architect Gating

**Cargar `@[.agent/agents/architect.md]` si:**

| Situación                      | Afecta |
| ------------------------------ | ------ |
| Data model complejo            | 06     |
| Decisión infra con tradeoffs   | 07     |
| Gap 🟡 que afecta arquitectura | 06, 07 |
| Soft-delete vs hard-delete     | 06     |

### Generar en este orden:

1. **07_ARCHITECTURE** — Stack decisions y ADRs
   - ADR-XXX decisiones con opciones consideradas
   - Stack patterns: caching, auth, realtime
   - Cross-ref: ADR→US, ADR→BR
   - **🔴 ADR Generation Guard:**
     - Leer Brief Decision Registry (§ final del Brief). Para cada decisión "Firm" con `risk_if_wrong` High, crear un ADR documentando decisión, alternativas, y rationale.
     - Si Brief §4 describe relaciones de datos no triviales (cardinalidad, ownership, 1:N vs 1:1), crear ADR.
     - Cada ADR DEBE cross-referenciar la sección del Brief de donde se deriva.

2. **06_DATA_MODEL** — Derivar de 04_USER_STORIES + 05_BUSINESS_RULES + **07_ARCHITECTURE ADRs**
   - E-XXX entidades con campos, tipos, FK
   - Timestamps (createdAt, updatedAt)
   - Indexes para queries frecuentes
   - Cross-ref: E→US, E→BR
   - Verificar Entity Reconciliation (tabla de Phase 3)
   - **🔴 Respetar ADRs de 07:** Si un ADR define cardinalidad, jerarquía, o estructura (ej: "1 Pick → N PickSelectionDetail"), el schema DEBE reflejarlo.
   - **🔴 Brief fields check:** Verificar que campos derivados de Business Rules en §6 (ej: `is_main_block` para lockdown) existan como columnas.

### 🔴 Checkpoint Intermedio 4 + Cross-Validation (HARD GATE — USAR notify_user)

> ⚠️ **Antes de presentar el checkpoint, el agente DEBE ejecutar cross-validation silenciosa:**
>
> 1. **ADR ↔ Data Model:** Para cada ADR en 07 que afecta schema, verificar que 06 lo refleja
> 2. **Decision Registry → Docs:** Para cada decisión "Firm" del Brief, verificar que aparece en el doc correcto
> 3. **Brief §6 fields → 06 columns:** Verificar que campos de Business Rules mapean a columnas del Data Model
> 4. **Entity Reconciliation count:** Verificar que 06 cubre el mismo # de entidades que Brief §4.1
>
> **Si detecta inconsistencia → corregir el doc ANTES de presentar el checkpoint.**

**El agente DEBE mostrar vía `notify_user`:**

```markdown
## ✅ Batch 4 Completado (Architecture + Data Model)

**Architecture:** ADR-001 → ADR-XXX ([N] decisiones, [N] del Decision Registry)
**Data Model:** E-001 → E-XXX ([N] entidades)
**Entity Reconciliation:** [N/total] entidades del Brief cubiertas

### Cross-Validation Results

| Check                         | Result |
| ----------------------------- | ------ |
| ADR ↔ Data Model consistency  | ✅/🔴  |
| Decision Registry propagation | ✅/🔴  |
| Brief §6 fields → columns     | ✅/🔴  |
| Entity count match            | ✅/🔴  |

¿Continuar con Batch 5 (API Contracts)?
```

**ACTION:** Call `notify_user` with `BlockedOnUser: true`, `ShouldAutoProceed: true`

🛑 **STOP — NO continuar con Batch 5 sin confirmación del usuario.**

---

## ═══════════════════════════════════════

## BATCH 5: API Contracts (08)

## ═══════════════════════════════════════

> **Output:** 08_API_CONTRACTS
>
> **Depende de:** Batch 4 (06_DATA_MODEL + 07_ARCHITECTURE)

### Generar:

1. **08_API_CONTRACTS** — Server Actions y I/O
   - Server Actions por feature
   - Input/Output schemas (Zod, derivados del Data Model)
   - Error handling patterns
   - Cross-ref: Action→US, Action→E-XXX

**Open Questions & Assumptions:**

> Cada documento DEBE tener sección de OQ y Assumptions.

### 🔴 Checkpoint Intermedio 5 (HARD GATE — USAR notify_user)

> ⚠️ **El agente DEBE pausar aquí para resetear contexto antes de Batch 6 (Operational).**

**El agente DEBE mostrar vía `notify_user`:**

```markdown
## ✅ Batch 5 Completado (API Contracts)

**API Contracts:** [N] server actions documentadas
**Cross-refs verificados:** Action→US: [N/total], Action→E: [N/total]

¿Continuar con Batch 6 (Operational: Runbooks, Tests, E2E, Risks, Traceability)?
```

**ACTION:** Call `notify_user` with `BlockedOnUser: true`, `ShouldAutoProceed: true`

🛑 **STOP — NO continuar con Batch 6 sin confirmación del usuario.**

---

## ═══════════════════════════════════════

## BATCH 6: Operational (10-14)

## ═══════════════════════════════════════

> **Output:** 10_RUNBOOKS, 11_TEST_STRATEGY, 12_E2E_SCENARIOS, 13_RISK_REGISTER, 14_TRACEABILITY
>
> **Depende de:** Todo lo anterior (02-09)

### Generar en este orden:

1. **10_RUNBOOKS** — Procedimientos operacionales del DOMINIO
   - RUN-XXX: Derivar de Discovery Brief §8 (Jobs/Operations) + §5 (Integraciones)
   - Enfoque en operaciones del DOMINIO del proyecto (ej: setup de temporada, backfill de datos, corrección de scores emergente)
   - **🔴 NO generar runbooks genéricos de deployment** — eso ya lo cubre Factory `/deploy`
   - Si el proyecto tiene crons/automation → documentar procedimientos de monitoreo y recovery

2. **11_TEST_STRATEGY** — Pirámide de tests
   - Niveles: Unit → Integration → E2E
   - Coverage goals por nivel
   - Herramientas: Vitest, Playwright
   - Derivado de 04_USER_STORIES (qué testear)

3. **12_E2E_SCENARIOS** — Flujos críticos
   - E2E-XXX con pasos y assertions
   - Prioridad: P0 → P1 → P2
   - Fixture data
   - Derivado de 04_USER_STORIES + 05_BUSINESS_RULES

4. **13_RISK_REGISTER** — Riesgos identificados
   - RSK-XXX con impacto × probabilidad × mitigación
   - Matriz de riesgos
   - Derivado de Discovery §8

5. **14_TRACEABILITY** — Stub de trazabilidad
   - US-XXX → Issue → Test → Deploy
   - Stub que `/backlog` poblará

### Open Questions & Assumptions

> Cada documento DEBE tener:

```markdown
---
## Open Questions

| # | Pregunta | Impacto | Owner |
  |---|----------|---------|-------|
  | OQ-01 | ... | Alto/Med/Bajo | Cliente/Dev |
---

## Assumptions

| #    | Supuesto | Si es incorrecto |
| ---- | -------- | ---------------- |
| A-01 | ...      | Impacto: ...     |
```

### 🔴 Checkpoint Intermedio 6 (HARD GATE — USAR notify_user)

> ⚠️ **El agente DEBE pausar aquí para resetear contexto antes de Phase 5 (Validation).**

**El agente DEBE mostrar vía `notify_user`:**

```markdown
## ✅ Batch 6 Completado (Operational)

**Runbooks:** RUN-001 → RUN-XXX ([N] procedimientos del dominio)
**Test Strategy:** [N] niveles definidos
**E2E Scenarios:** E2E-001 → E2E-XXX ([N] flujos críticos)
**Risk Register:** RSK-001 → RSK-XXX ([N] riesgos)
**Traceability:** Stub generado

¿Continuar con Phase 5 (Validation & Gap Analysis)?
```

**ACTION:** Call `notify_user` with `BlockedOnUser: true`, `ShouldAutoProceed: true`

🛑 **STOP — NO continuar a Phase 5 (Validation) sin confirmación del usuario.**

---

_Phase 4 Complete → Continuar a Phase 5 (Validation)_
