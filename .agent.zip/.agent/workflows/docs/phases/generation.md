# Phase 3: Generate Core Docs (2-Batch)

> **Carga:** Después de CHECKPOINT 1 aprobado
>
> **Estrategia:** Generar en 2 batches para evitar context degradation.
> Batch 1 (Foundation) son inputs de Batch 2 (Behavior).

---

## Doc Catalog (Core — Phase 3)

| #   | Documento      | Contenido                          | SSOT     | Batch |
| --- | -------------- | ---------------------------------- | -------- | ----- |
| 02  | FEATURE_MAP    | Features MVP/Post-MVP, Non-Goals   | Este doc | 1     |
| 03  | USER_PERSONAS  | Perfiles, JTBD, RBAC Matrix        | Este doc | 1     |
| 09  | GLOSSARY       | Vocabulario del dominio            | Este doc | 1     |
| 04  | USER_STORIES   | Historias con FT-XXX, AC, test     | Este doc | 2     |
| 05  | BUSINESS_RULES | Invariantes, validaciones, estados | Este doc | 2     |

---

## Crear archivos desde templates

```bash
mkdir -p ./docs/planning
for doc in 02_FEATURE_MAP 03_USER_PERSONAS 04_USER_STORIES 05_BUSINESS_RULES 06_DATA_MODEL 07_ARCHITECTURE 08_API_CONTRACTS 09_GLOSSARY; do
  [ ! -f ./docs/planning/${doc}.md ] && cp ./.agent/skills/roles/docs/${doc}.template.md ./docs/planning/${doc}.md
done
```

---

## Starter Kit Awareness (MANDATORY)

> 🔴 **Al documentar, diferenciar lo existente de lo nuevo.**
>
> INVENTORY.md y CODEBASE.md se cargaron en Phase 1 (context-loading.md).

| En el doc        | Si ya existe en SK                                              | Si es nuevo                    |
| ---------------- | --------------------------------------------------------------- | ------------------------------ |
| 06_DATA_MODEL    | `🏗️ SK` — documentar schema existente, no marcar como "a crear" | `🆕` — diseñar schema completo |
| 07_ARCHITECTURE  | Referenciar stack existente como decisión tomada                | Nuevas decisiones como ADR     |
| 08_API_CONTRACTS | `🏗️ SK` — documentar actions existentes                         | `🆕` — definir nuevas actions  |

---

## Scope Preservation (MANDATORY)

> 🔴 **NO recortar, resumir, ni consolidar features del Discovery Brief.**
>
> CADA feature de §3 (MVP) DEBE tener su correspondiente FT-XXX en 02_FEATURE_MAP.

**REGLA:** Al generar 02_FEATURE_MAP y 04_USER_STORIES:

| Situación                                       | Acción                                |
| ----------------------------------------------- | ------------------------------------- |
| Feature §3 MVP → FT-XXX                         | ✅ Obligatorio                        |
| Feature §3 Post-MVP → FT-XXX (marcado post-MVP) | ✅ Documentar                         |
| Feature §3 que "parece redundante"              | ⚠️ NO eliminar — preguntar al usuario |
| Feature §3 que "ya existe en SK"                | ✅ Documentar con `🏗️ SK Provided`    |

**NUNCA:**

- ❌ Asumir que un feature "no es necesario"
- ❌ Consolidar 2+ features en uno sin aprobación
- ❌ Cambiar feature de MVP a Post-MVP sin consultar
- ❌ Omitir features porque "son obvios"

---

## Entity & Screen Reconciliation (MANDATORY)

> 🔴 **ANTES de generar 06_DATA_MODEL (Batch 3), crear tablas de reconciliación.**
>
> Este paso previene el caso real: Brief §3.1 lista entidades que nunca llegan a E-XXX.

**Tabla 1: Entidades (Brief §3.1 + §4.1 → docs)**

| #   | Entidad Brief | Brief §ref | E-XXX asignado | Doc destino   | Status |
| --- | ------------- | ---------- | -------------- | ------------- | ------ |
| 1   | [entidad]     | §3.1/§4.1  | E-001          | 06_DATA_MODEL | ✅/❌  |

**Tabla 2: Pantallas (Brief §7.2 → docs)**

| #   | Pantalla Brief | Brief §ref | Anotada para | Status |
| --- | -------------- | ---------- | ------------ | ------ |
| 1   | [pantalla]     | §7.2       | 15_DESIGN    | ✅/❌  |

**Tabla 3: Features → Entidades → Pantallas (Cross-Map)**

| #   | Feature Brief §3 | FT-XXX | Entidades involucradas | Pantallas |
| --- | ---------------- | ------ | ---------------------- | --------- |
| 1   | [feature]        | FT-001 | E-001, E-002           | Dashboard |

**🛑 GATE:** Si CUALQUIER entidad o pantalla del Brief no tiene E-XXX o destino asignado →
STOP. Justificar exclusión o agregar.

---

## ID Formats (consistentes)

| Tipo      | Formato | Orden              |
| --------- | ------- | ------------------ |
| Features  | FT-XXX  | Orden en §3        |
| Non-Goals | NG-XXX  | Orden de aparición |
| Personas  | P-XXX   | Orden en §2        |
| Stories   | US-XXX  | Por feature        |
| Rules     | BR-XXX  | Orden en §6        |
| Entities  | E-XXX   | Alfabético         |
| ADRs      | ADR-XXX | Orden de decisión  |

---

## ═══════════════════════════════════════

## BATCH 1: Foundation (02 + 03 + 09)

## ═══════════════════════════════════════

> **Output:** 02_FEATURE_MAP, 03_USER_PERSONAS, 09_GLOSSARY

**Generar en este orden:**

1. **02_FEATURE_MAP** — Extraer TODOS los features de Brief §3
   - MVP features con FT-XXX
   - Post-MVP features marcados
   - Non-Goals con NG-XXX
   - Cross-ref: §3 features → FT-XXX (1:1 obligatorio)

2. **03_USER_PERSONAS** — Extraer personas de Brief §2
   - Perfiles con P-XXX
   - JTBD (Jobs To Be Done) por persona
   - RBAC Matrix: P-XXX × recurso → permiso

3. **09_GLOSSARY** — Vocabulario del dominio
   - Términos técnicos y de negocio
   - Derivado de §3+§6 del Brief

### 🔴 Checkpoint Intermedio 1 (HARD GATE — USAR notify_user)

> ⚠️ **El agente DEBE pausar aquí para resetear contexto antes de Batch 2.**

**El agente DEBE mostrar vía `notify_user`:**

```markdown
## ✅ Batch 1 Completado (Foundation)

**Feature Map:** FT-001 → FT-XXX ([N] features, [M] MVP / [K] Post-MVP)
**Personas:** P-001 → P-XXX ([N] personas)
**Glossary:** [N] términos
**Coverage vs Brief §3:** [N/total] features mapeados

¿Continuar con Batch 2 (User Stories)?
```

**ACTION:** Call `notify_user` with `BlockedOnUser: true`, `ShouldAutoProceed: true`

🛑 **STOP — NO continuar con Batch 2 sin confirmación del usuario.\*\***

---

## ═══════════════════════════════════════

## BATCH 2: User Stories (04)

## ═══════════════════════════════════════

> **Output:** 04_USER_STORIES
>
> **Estrategia:** Sub-batching por épicas para evitar context degradation.
> En proyectos con muchas stories (>20), generar todas de golpe degrada
> la calidad de las últimas. Partir en grupos de 3-4 épicas.

### Quality Floor (OBLIGATORIO)

> 🔴 **CADA User Story DEBE cumplir estos mínimos:**

| Prioridad       | Mínimo Gherkin                   | Cross-refs                |
| --------------- | -------------------------------- | ------------------------- |
| **Must Have**   | 2 scenarios (happy + error/edge) | FT-XXX + BR-XXX si aplica |
| **Should Have** | 1 scenario (happy path)          | FT-XXX                    |

**Reglas adicionales:**

- Cada scenario DEBE usar Given/When/Then con **datos concretos** (no genéricos)
- Si la US referencia una BR-XXX, el scenario DEBE validar esa BR explícitamente
- Cross-ref obligatorio: US→FT-XXX (feature que implementa), US→P-XXX (persona)

### Generar User Stories

1. **04_USER_STORIES** — Derivar de 02_FEATURE_MAP
   - US-XXX por feature (FT-XXX → US-XXX)
   - Acceptance Criteria con Gherkin (cumplir Quality Floor)
   - Cross-ref: US→FT, US→P-XXX

### Sub-batching por épicas

> ⚠️ **Agrupar épicas en sub-batches de máximo 3-4 épicas (~10-12 stories).**
>
> Después de cada sub-batch, el agente ejecuta **self-check silencioso:**
>
> 1. Contar stories generadas en este sub-batch
> 2. Verificar que CADA story Must Have tiene ≥ 2 scenarios Gherkin
> 3. Verificar que CADA story Should Have tiene ≥ 1 scenario Gherkin
> 4. Si alguna story no cumple → **completarla ANTES de continuar**
> 5. Mostrar mini-resumen en chat (NO notify_user):
>    `"Sub-batch [N]: [X] stories (E1-E4), Gherkin: [N/N] ✅"`

**Open Questions & Assumptions:**

> Cada documento DEBE tener:

```markdown
---
## Open Questions

| # | Pregunta | Impacto | Owner |
  |---|----------|---------|-------|
  | OQ-01 | ... | Alto/Med/Bajo | Cliente/Dev |
---

## Assumptions

| #    | Supuesto | Si es incorrecto |
| ---- | -------- | ---------------- |
| A-01 | ...      | Impacto: ...     |
```

### 🔴 Checkpoint Intermedio 2 (HARD GATE — USAR notify_user)

> ⚠️ **El agente DEBE pausar aquí para resetear contexto antes de Batch 3 (Business Rules).**

**El agente DEBE mostrar vía `notify_user`:**

```markdown
## ✅ Batch 2 Completado (User Stories)

**User Stories:** US-001 → US-XXX ([N] total)
**Quality Floor:** [N/N] stories con Gherkin mínimo ✅
**Cross-refs verificados:** US→FT: [N/total]
**Sub-batches procesados:** [N]

¿Continuar con Batch 3 (Business Rules)?
```

**ACTION:** Call `notify_user` with `BlockedOnUser: true`, `ShouldAutoProceed: true`

🛑 **STOP — NO continuar con Batch 3 sin confirmación del usuario.**

---

## ═══════════════════════════════════════

## BATCH 3: Business Rules (05)

## ═══════════════════════════════════════

> **Output:** 05_BUSINESS_RULES
>
> **Depende de:** 04_USER_STORIES (para cross-ref BR→US)

**Generar:**

1. **05_BUSINESS_RULES** — Derivar de Brief §6
   - BR-XXX invariantes y validaciones
   - Estados y transiciones
   - Cálculos con fórmulas explícitas (CALC-XXX)
   - Cross-ref: BR→US, BR→E-XXX (si schema ya está en Brief)

**Open Questions & Assumptions:**

> Cada documento DEBE tener sección de OQ y Assumptions (mismo formato de Batch 2).

### 🔴 Checkpoint Intermedio 3 (HARD GATE — USAR notify_user)

> ⚠️ **El agente DEBE pausar aquí para resetear contexto antes de Phase 4 (Technical docs).**

**El agente DEBE mostrar vía `notify_user`:**

```markdown
## ✅ Batch 3 Completado (Business Rules)

**Business Rules:** BR-001 → BR-XXX ([N] total)
**Cross-refs verificados:** BR→US: [N/total]

¿Continuar con Phase 4 (Technical + Operational docs)?
```

**ACTION:** Call `notify_user` with `BlockedOnUser: true`, `ShouldAutoProceed: true`

🛑 **STOP — NO continuar con Phase 4 sin confirmación del usuario.**

---

## Architect Gating

**Cargar `@[.agent/agents/architect.md]` si:**

| Situación                      | Afecta |
| ------------------------------ | ------ |
| Data model complejo            | 06     |
| Decisión infra con tradeoffs   | 07     |
| Gap 🟡 que afecta arquitectura | 06, 07 |
| Soft-delete vs hard-delete     | 06     |

---

_Phase 3 Complete → Continuar a Phase 4 (Technical + Operational Docs)_
