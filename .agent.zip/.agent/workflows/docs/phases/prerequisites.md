# Phase 2: Prerequisites

> **Carga:** Después de context-loading.md

---

## Phase 2: Verify Discovery Brief

// turbo

```bash
ls -la ./docs/planning/00_DISCOVERY_BRIEF.md 2>/dev/null || echo "❌ Discovery Brief not found"
```

**Si no existe:**

```markdown
⚠️ **Discovery Brief no encontrado**
**Acción:** Ejecutar `/discovery` primero.
```

---

## Phase 3: Load Discovery Brief

// turbo

```bash
cat ./docs/planning/00_DISCOVERY_BRIEF.md
```

---

## Phase 4: Validate Coverage Map

**Verificar que §1, §2, §3, §6 están ✅ en el Brief.**

| Sección | Contenido         | Requerido |
| ------- | ----------------- | --------- |
| §1      | Idea General      | ✅        |
| §2      | Usuarios y Roles  | ✅        |
| §3      | Features Core     | ✅        |
| §6      | Reglas de Negocio | ✅        |

**Si alguna está 🔴 → STOP**

---

## Phase 5: Load Templates

// turbo

```bash
ls -la ./.agent/skills/roles/docs/*.template.md
```

**Templates disponibles (02-14):**

- 02_FEATURE_MAP.template.md
- 03_USER_PERSONAS.template.md (incluye RBAC Matrix)
- 04_USER_STORIES.template.md
- 05_BUSINESS_RULES.template.md
- 06_DATA_MODEL.template.md
- 07_ARCHITECTURE.template.md
- 08_API_CONTRACTS.template.md
- 09_GLOSSARY.template.md
- 10_RUNBOOKS.template.md
- 11_TEST_STRATEGY.template.md
- 12_E2E_SCENARIOS.template.md
- 13_RISK_REGISTER.template.md
- 14_TRACEABILITY.template.md

> ⚠️ **Nota:** 01_PROPOSAL se genera con `/proposal` (workflow separado)

---

## 🛑 CHECKPOINT 1: Pre-Generation

**Mostrar:**

```markdown
## 📋 Pre-Generation Summary

**Discovery Brief:** Cargado ✅
**Coverage Map:** §1,§2,§3,§6 = ✅
**Templates:** Listos ✅
**Docs a generar:**

- **Core (02-09):** 02_FEATURE_MAP, 03_USER_PERSONAS, 04_USER_STORIES, 05_BUSINESS_RULES, 06_DATA_MODEL, 07_ARCHITECTURE, 08_API_CONTRACTS, 09_GLOSSARY
- **Extended (10-14):** 10_RUNBOOKS, 11_TEST_STRATEGY, 12_E2E_SCENARIOS, 13_RISK_REGISTER, 14_TRACEABILITY

| #   | Opción   | Acción                 |
| --- | -------- | ---------------------- |
| 1   | generar  | Crear todos los docs   |
| 2   | solo X   | Generar doc específico |
| 3   | cancelar | Salir                  |

**¿Qué quieres hacer?** (1-3)
```

**ACTION:** Call `notify_user` with `BlockedOnUser: true`

🛑 **STOP AQUÍ — NO continuar sin respuesta del usuario.**

---

_Phase 2-5 Complete → ESPERAR CHECKPOINT 1 → Continuar a Phase 6-7_
