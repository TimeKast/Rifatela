# Phase 1: Context Loading

> **Propósito:** Cargar knowledge base, agentes, skills, y docs de referencia.
> **Se ejecuta SIEMPRE.**

---

## 1.1 Load Knowledge Base

// turbo

```bash
cat ./.agent/skills/roles/docs/SKILL.md
```

// turbo

```bash
cat ./docs/planning/project-config.md 2>/dev/null || echo "No project-config.md"
```

---

## 1.2 Previous Validation Report

> 📄 **Cargar reporte de validación del paso anterior** (si existe).

// turbo

```bash
PREV_REPORT=$(ls docs/reports/validation_proposal_*.md 2>/dev/null | head -1)
[ -n "$PREV_REPORT" ] && { echo "📋 Loading: $PREV_REPORT"; cat "$PREV_REPORT"; } || echo "📝 No previous validation report (validation_proposal_*)"
```

---

## 1.3 Load Reference Docs

> 📖 **Cargar docs de referencia del SK.**
> CODEBASE solo TOC (awareness). El resto full para generar todos los docs.

// turbo

```bash
echo "📖 Loading Reference Docs..."
for ref in ./docs/reference/*.md; do
  if [ -f "$ref" ]; then
    BASENAME=$(basename "$ref")
    if [ "$BASENAME" = "CODEBASE.md" ]; then
      echo "--- $BASENAME (TOC) ---"
      head -30 "$ref"
    else
      echo "--- $BASENAME ---"
      cat "$ref"
    fi
  fi
done
```

---

## 1.4 Load Guides

// turbo

```bash
# Project structure — relevante para 07_ARCHITECTURE
cat ./docs/guides/project-structure.md 2>/dev/null || echo "No project-structure guide"
```

---

## 1.5 SSOT Documents (MANDATORY)

> 🔴 **OBLIGATORIO** — Docs deriva de Discovery + Proposal.
>
> **Chain:** Discovery (00) → Proposal (01) → **Docs** (02-14)

// turbo

```bash
cat ./docs/planning/00_DISCOVERY_BRIEF.md 2>/dev/null || echo "⚠️ No 00_DISCOVERY_BRIEF.md"
```

// turbo

```bash
cat ./docs/planning/01_PROPOSAL.md 2>/dev/null || echo "⚠️ No 01_PROPOSAL.md"
```

---

## 1.6 Kit Skills Loading

> 🎯 **Skills del Kit para documentación técnica**

// turbo

```bash
# Documentation templates (SIEMPRE cargar)
cat ./.agent/skills/documentation-templates/SKILL.md 2>/dev/null | head -60 || echo "No documentation-templates"
```

// turbo

```bash
# Architecture decisions
cat ./.agent/skills/architecture/SKILL.md 2>/dev/null | head -60 || echo "No architecture skill"
```

// turbo

```bash
# Plan writing
cat ./.agent/skills/plan-writing/SKILL.md 2>/dev/null | head -60 || echo "No plan-writing skill"
```

---

## 1.7 Agent Context Loading

> 🤖 **Agentes para docs**

// turbo

```bash
# Documentation writer (core)
cat ./.agent/agents/documentation-writer.md
```

// turbo

```bash
# Architect (decisiones técnicas para 06, 07)
cat ./.agent/agents/architect.md
```

// turbo

```bash
# Explorer para API discovery si hay código
ls ./src/lib/actions 2>/dev/null && cat ./.agent/agents/explorer-agent.md
```

---

## 1.8 Project-Specific Loading

> 🎯 **Si el proyecto tiene agentes o skills propios, cargarlos para contexto de dominio.**
>
> Esto da al agente conocimiento específico del dominio (ej: reglas deportivas, lógica financiera)
> que mejora significativamente la calidad de 06_DATA_MODEL, 07_ARCHITECTURE, y 10_RUNBOOKS.

// turbo

```bash
PROJECT_LOADED=""

# Check project registry
if [ -f "./.agent/registry/project.yaml" ]; then
  echo "📦 Loading project registry..."
  cat ./.agent/registry/project.yaml
  PROJECT_LOADED="registry"
fi

# Load project agents (if any)
if [ -d "./.agent/agents/project" ]; then
  echo ""
  echo "🤖 Loading project agents..."
  for agent in ./.agent/agents/project/*.md; do
    [ -f "$agent" ] || continue
    echo "--- $(basename $agent) ---"
    head -100 "$agent"
    PROJECT_LOADED="${PROJECT_LOADED} agents"
  done
fi

# Load project skills (if any)
if [ -d "./.agent/skills/project" ]; then
  echo ""
  echo "🧰 Loading project skills..."
  for skill in ./.agent/skills/project/*/SKILL.md; do
    [ -f "$skill" ] || continue
    echo "--- $(dirname $skill | xargs basename) ---"
    head -100 "$skill"
    PROJECT_LOADED="${PROJECT_LOADED} skills"
  done
fi

if [ -z "$PROJECT_LOADED" ]; then
  echo "ℹ️  No project-specific agents or skills found — using Kit defaults only"
fi
```

---

_Phase 1 Complete → Continuar a Phase 2 (Prerequisites)_
