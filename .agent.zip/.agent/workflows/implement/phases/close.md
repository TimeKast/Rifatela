# Phase 6: Close (Document + Commit + Handoff)

> **Carga:** Solo DESPUÉS de CHECKPOINT 2 aprobado.
>
> 🔴 **ORDEN CRÍTICO:** Documentar → Commit → Handoff

---

## 6.1 Code Documentation (Conditional)

> 📝 **Solo si aplica al tipo de cambio:**

| Si el issue toca...           | Entonces...        |
| ----------------------------- | ------------------ |
| Funciones públicas en `lib/`  | JSDoc obligatorio  |
| Feature visible para usuario  | README update      |
| Cambio en API/schema/breaking | CHANGELOG entry    |
| Docs/workflow/script          | Ninguno (skip 6.1) |

---

## 6.2 Issue Documentation (MANDATORY)

> 🔴 **ANTES de commit.** Part of DoD.

**Agregar sección Implementation Evidence al issue:**

```markdown
## 📝 Implementation Evidence

### Decisions Made

| Decisión       | Razón                        |
| -------------- | ---------------------------- |
| Patrón X usado | Por rendimiento/consistencia |
| No incluido Y  | Fuera de scope               |

### Artifacts Created

- `path/to/new-file.ts` — propósito
- `path/to/new-file.test.ts` — tests

### Verification

- [x] Typecheck: Pass
- [x] Lint: Pass
- [x] Tests: X passing

### Commit

`hash` feat(scope): description

---

_Completado: YYYY-MM-DD_
```

> 📝 **Tasks `[ ]` en el issue body se marcan `[x]` durante Phase 4 (tracking operativo).**
> Implementation Evidence es el **resumen final** — no repetir evidencia por task.

**Smoke check (no calidad, solo presencia):**

// turbo

```bash
grep -q "Implementation Evidence" ./docs/backlog/*/issues/${ISSUE_ID}*.md && echo "✅ Evidence section present" || echo "🔴 FALTA — agregar antes de commit"
```

---

## 6.3 Update Issue Status

```markdown
> **Status:** ✅ Done
```

---

## 6.4 Commit + Push

```bash
git add .
git commit -m "feat(scope): description ({ISSUE-ID})"
git push
```

// turbo

```bash
grep -q "Status.*Done" ./docs/backlog/*/issues/${ISSUE_ID}*.md && echo "✅ Issue cerrado correctamente"
```

---

## 6.5 Update Board (best-effort, no blocker)

// turbo

```bash
pnpm update-board 2>/dev/null && echo "✅ Board actualizado" || echo "ℹ️ update-board no disponible (best-effort)"
```

---

## 6.6 Handoff Final

```markdown
## ✅ {ISSUE-ID} Completado

**Artefactos:**

- Archivos creados: [X]
- Archivos modificados: [Y]
- Tests: passing

**Commit:** `hash` feat(scope): description

**Próximo:** `/implement {NEXT-ID}` o `/audit`
```

---

_Close Complete → Issue cerrado_
