---
description: Initialize session - load project context and show status
---

# /init — Session Initialization

> Load project context and available resources for AI-first development.
> Run this at the start of every session.
> Rules (`04_complementary.md`, `HIERARCHY.md`, `ROUTING.md`) are auto-loaded via user rules.
>
> **TimeKast Factory v2.4** — 2026-03-01

---

## Phase 1: Core Context Loading

> Rules (`04_complementary.md`, `HIERARCHY.md`, `ROUTING.md`) are injected automatically via user rules — no need to load them here.

> 📖 Para índice completo de workflows, skills y agentes: `.agent/CONTENTS.md`

---

## Phase 2: Project Config & Inventory

// turbo

```bash
cat ./docs/planning/project-config.md 2>/dev/null || echo "No project-config.md"
```

// turbo

```bash
cat ./docs/reference/INVENTORY.md 2>/dev/null || echo "No INVENTORY.md - run 'pnpm generate:inventory' to create"
```

// turbo

```bash
cat ./docs/reference/CODEBASE.md 2>/dev/null || echo "No CODEBASE.md - run 'pnpm generate:codebase' to create"
```

---

## Phase 3: Backlog Status

> **Prioridad:** BOARD.md (auto-generado, confiable) > README (manual, puede estar desactualizado)

// turbo

```bash
# 1. BOARD.md es la fuente más confiable (auto-actualizado en commits)
if [ -f "./docs/backlog/BOARD.md" ]; then
  echo "📋 Sprint Board (auto-generated):"
  cat ./docs/backlog/BOARD.md
else
  echo "⬜ No BOARD.md - run 'pnpm update-board' to generate"
fi
```

// turbo

```bash
# 2. README del backlog para contexto adicional (puede estar desactualizado)
VERSION=$(ls -d ./docs/backlog/v*/ 2>/dev/null | sort -V | tail -1 | xargs basename 2>/dev/null || echo "none")
if [ "$VERSION" != "none" ]; then
  echo ""
  echo "📄 Backlog README (v$VERSION):"
  echo "---"
  # Solo mostrar primeras 30 líneas del README (resumen)
  head -30 ./docs/backlog/${VERSION}/README.md 2>/dev/null || true
  echo "..."
  echo "(Use 'cat docs/backlog/${VERSION}/README.md' for full context)"
else
  echo "No backlog versions - run /backlog to create"
fi
```

> **Nota:** Si BOARD.md y README difieren, BOARD.md es la fuente de verdad.

---

## Phase 4: Project Status Check

// turbo

```bash
# Git status
git branch --show-current 2>/dev/null || true
git status --short 2>/dev/null || true
```

---

## Phase 5: Available Skills

List available skills for on-demand loading:

### Role Skills

| Skill            | Invocation   | Use Case                                  |
| ---------------- | ------------ | ----------------------------------------- |
| Discovery Expert | `/discovery` | Product discovery, requirements gathering |
| Proposal Expert  | `/proposal`  | Client-facing scope document              |
| Docs Expert      | `/docs`      | Generate planning docs (02-14)            |
| Design Expert    | `/design`    | Generate 15_DESIGN.md                     |
| Backlog Expert   | `/backlog`   | Create issues from design                 |
| Implement Expert | `/implement` | Execute issues through pipeline           |

### Domain Skills (load on demand)

| Skill       | When to Load                  |
| ----------- | ----------------------------- |
| `api/`      | API routes, server actions    |
| `db/`       | Database, Drizzle, migrations |
| `security/` | Auth, RBAC, security review   |
| `testing/`  | Tests, coverage, fixtures     |
| `ui/`       | Components, design system     |

---

## Phase 6: Development Pipeline

### 🚀 Flujo de Desarrollo Completo

```
┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│ /discovery  │───►│ /proposal   │───►│   /docs     │
│ Brief       │    │ Cliente     │    │ Técnico     │
└─────────────┘    └──────┬──────┘    └──────┬──────┘
                          │                  │
                    /validate_docs      /validate_docs
                          │                  │
┌─────────────┐    ┌──────▼──────┐    ┌──────▼──────┐
│ /implement  │◄───│  /backlog   │◄───│  /design    │
│ Code        │    │  Issues     │    │  UI/UX      │
└─────────────┘    └──────┬──────┘    └──────┬──────┘
                          │                  │
                    /validate_docs      /validate_docs
```

### ¿Dónde estás?

| Si tienes...         | Siguiente paso           | Workflow              |
| -------------------- | ------------------------ | --------------------- |
| Nada / idea inicial  | Entender el problema     | `/discovery`          |
| Discovery Brief      | Propuesta para cliente   | `/proposal`           |
| Propuesta aprobada   | Documentación técnica    | `/docs`               |
| Docs 02-14 completos | Especificación UI/UX     | `/design`             |
| Design 15 completo   | Crear issues del backlog | `/backlog`            |
| Issues en backlog    | Implementar código       | `/implement ISSUE-ID` |

---

## Phase 7: Available Workflows

### Bootstrap Pipeline

| Workflow     | Purpose                        | Prerequisito      | Output                         |
| ------------ | ------------------------------ | ----------------- | ------------------------------ |
| `/discovery` | Entender problema y requisitos | Input del usuario | `00_DISCOVERY_BRIEF.md`        |
| `/proposal`  | Propuesta para cliente         | Discovery Brief   | `docs/planning/01_PROPOSAL.md` |
| `/docs`      | Documentación técnica (02-14)  | Proposal aprobada | `docs/planning/02-14_*.md`     |
| `/design`    | Especificación UI/UX           | Docs 02-14        | `docs/planning/15_DESIGN.md`   |
| `/backlog`   | Crear issues del diseño        | Design 15         | Issues en `docs/backlog/`      |
| `/implement` | Implementar issue              | Issue ID          | Código + tests                 |

### Utilities

| Workflow         | Purpose               | Cuándo usar                                    |
| ---------------- | --------------------- | ---------------------------------------------- |
| `/init`          | Inicializar sesión    | Al comenzar cada sesión                        |
| `/park`          | Guardar ideas         | Cuando surge algo fuera de scope               |
| `/audit`         | Quick audit           | Auditoría rápida por tipo                      |
| `/audit_deep`    | Quality audit (R0-R4) | Pre-release o post-epic                        |
| `/validate_docs` | Validar docs (V1-V3)  | Después de /proposal, /docs, /design, /backlog |
| `/debug`         | Investigación de bugs | Fixes rápidos sin issue formal                 |

### Agents (invocar con @[path])

| Agent               | Path                                      | Cuándo                    |
| ------------------- | ----------------------------------------- | ------------------------- |
| Architect           | `@[.agent/agents/architect.md]`           | Decisiones técnicas, ADRs |
| Quality Engineer    | `@[.agent/agents/quality-engineer.md]`    | Audits, security          |
| Backend Specialist  | `@[.agent/agents/backend-specialist.md]`  | API, server actions       |
| Frontend Specialist | `@[.agent/agents/frontend-specialist.md]` | UI, components            |
| Database Architect  | `@[.agent/agents/database-architect.md]`  | Schema, migrations        |

> 📖 Lista completa: `.agent/registry/views/REGISTRY.md` (29 agents, 48 skills)

---

## Phase 8: Output Summary

Present to user:

```markdown
## 🚀 Session Initialized

### Bienvenido a TimeKast Factory

### 📋 Loaded Context

- [x] Rules (auto-loaded via user rules)
- [x] CONTENTS.md (reference)
- [x] project-config.md (or note if missing)
- [x] INVENTORY.md (or note if missing)

### 📊 Project Status

- **Project:** [name from project-config]
- **Branch:** [current branch]
- **Uncommitted changes:** [yes/no]

### 📋 Backlog Status

- **Version:** [v1.0 or latest]
- **Open issues:** [count] (📋 Backlog)
- **In progress:** [count] (🚧 In Progress)
- **Blocked:** [count] (🚫 Blocked)

### 🛠️ Available Actions

| Action             | Command                         |
| ------------------ | ------------------------------- |
| Implement feature  | `/implement AUTH-001`           |
| Create issues      | `/backlog`                      |
| Validate docs      | `/validate_docs`                |
| Technical decision | `@[.agent/agents/architect.md]` |
| Quality review     | `/audit_deep`                   |
| Park idea          | `/park "idea"`                  |
| Debug issue        | `/debug`                        |

### 💡 Suggested Next

Based on project status:

- If issues in progress → Continue with `/implement {ISSUE-ID}`
- If clean state → "Ready for `/implement` or `/audit_deep`"
- If uncommitted changes → "Review changes before proceeding"
```

### 💡 ¿Qué quieres hacer?

**📍 Bootstrap (proyectos nuevos):**

| #   | Paso                  | Workflow              | Descripción                |
| --- | --------------------- | --------------------- | -------------------------- |
| 1   | Entender problema     | `/discovery`          | Genera Discovery Brief     |
| 2   | Crear propuesta       | `/proposal`           | Documento para cliente     |
| 3   | Documentación técnica | `/docs`               | 02-14 planning docs        |
| 4   | Diseño UI/UX          | `/design`             | 15_DESIGN.md               |
| 5   | Crear issues          | `/backlog`            | Convierte diseño en issues |
| 6   | Implementar           | `/implement ISSUE-ID` | Código + tests             |

**🔧 Desarrollo (proyectos existentes):**

| #   | Acción              | Workflow              | Cuándo                                         |
| --- | ------------------- | --------------------- | ---------------------------------------------- |
| 7   | Implementar feature | `/implement AUTH-001` | Tienes issue en backlog                        |
| 8   | Validar docs        | `/validate_docs`      | Después de /proposal, /docs, /design, /backlog |
| 9   | Guardar idea        | `/park "idea"`        | Surge algo fuera de scope                      |
| 10  | Auditoría rápida    | `/audit`              | Auditoría rápida por tipo                      |
| 11  | Auditoría profunda  | `/audit_deep`         | Pre-release o post-epic                        |

**🏛️ Consultar expertos (usar @[path]):**

| #   | Experto          | Invocación                             | Cuándo                         |
| --- | ---------------- | -------------------------------------- | ------------------------------ |
| 10  | Arquitecto       | `@[.agent/agents/architect.md]`        | Decisiones de schema, patterns |
| 11  | Quality Engineer | `@[.agent/agents/quality-engineer.md]` | Revisión de calidad, security  |
| 12  | Debugger         | `@[.agent/agents/debugger.md]`         | Bugs complejos                 |

---

## Optional: Deep Context Loading

If user asks for more context or working on specific area:

```bash
# Load specific domain skill
cat ./.agent/skills/domains/[domain]/SKILL.md

# Load kit skill
cat ./.agent/skills/[skill]/SKILL.md

# Load project design (if exists)
cat ./docs/planning/15_DESIGN.md 2>/dev/null || true
```

---

## Gates/Escalation

| Trigger                     | Acción                            | Cuándo                 |
| --------------------------- | --------------------------------- | ---------------------- |
| project-config.md no existe | Crear básico o preguntar          | Proyecto nuevo         |
| INVENTORY.md desactualizado | `pnpm generate:inventory`         | Componentes nuevos     |
| Backlog vacío               | Sugerir `/backlog` o `/discovery` | Proyecto nuevo         |
| Branch diverge de main      | Advertir, sugerir merge/rebase    | Conflictos potenciales |

---

## Stop Conditions

| Condición                  | Severidad | Acción                         |
| -------------------------- | --------- | ------------------------------ |
| Rules no cargadas          | P0        | 🛑 STOP — Verificar user rules |
| Proyecto no es TimeKast SK | P1        | Advertir, ofrecer setup        |
| Git no inicializado        | P2        | Sugerir `git init`             |

---

_TimeKast Starter Kit — Session Initialization Workflow_
