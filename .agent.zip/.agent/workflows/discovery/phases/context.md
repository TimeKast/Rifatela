# Phase 0: Mode Detection + Context Status

> **Propósito:** Detectar modo y mostrar estado del contexto.
> **Sin carga de datos** — solo detección y status.

---

## 0.1 Context Status (MANDATORY)

> 🔴 **MANDATORY OUTPUT — NO SKIP**

```markdown
## 📊 Context Status

| Metric            | Value        | Status   |
| ----------------- | ------------ | -------- |
| Conversación      | [N] mensajes | 🟢/🟡/🔴 |
| Contexto estimado | [X]%         | 🟢/🟡/🔴 |

**Workflow:** /discovery
**Mode:** D0/D1/D2
**Timestamp:** [fecha-hora]
```

| Contexto | Status      | Acción                   |
| -------- | ----------- | ------------------------ |
| < 30%    | 🟢 OK       | Continuar normalmente    |
| 30-50%   | 🟡 Moderate | Continuar con precaución |
| > 50%    | 🔴 HIGH     | ⚠️ Recomendar nuevo chat |

---

_Phase 0 Complete → Continuar a Phase 1 (Context Loading)_
