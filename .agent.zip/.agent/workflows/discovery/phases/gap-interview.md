# Phase 3: Gap Interview

> **Propósito:** Evaluar cobertura y preguntar solo gaps reales — preservar source-of-truth.

---

## A. Coverage Model

La cobertura ya no se mide solo por secciones. Hay **6 dimensiones:**

```markdown
## Discovery Coverage

| Dimensión                   | Estado   | Notas                          |
| --------------------------- | -------- | ------------------------------ |
| Source classification       | ✅/🟡/🔴 | Docs clasificados y procesados |
| Firm decisions frozen       | ✅/🟡/🔴 | Freeze Map completo            |
| Contradictions mapped       | ✅/🟡/🔴 | Conflictos identificados       |
| Critical gaps identified    | ✅/🟡/🔴 | Huecos priorizados             |
| Structural section coverage | ✅/🟡/🔴 | §1-§11                         |
| Drift control               | ✅/🟡/🔴 | Sin cambios no autorizados     |
```

### Coverage estructural por sección

```markdown
| #   | Sección                | Estado      | Confidence                | Notas |
| --- | ---------------------- | ----------- | ------------------------- | ----- |
| §1  | Idea General           | ✅/🟡/🔴/⚪ | Confirmed/Partial/Missing |       |
| §2  | Usuarios y Roles       | ✅/🟡/🔴/⚪ |                           |       |
| §3  | Funcionalidades Core   | ✅/🟡/🔴/⚪ |                           |       |
| §4  | Modelo de Datos        | ✅/🟡/🔴/⚪ |                           |       |
| §5  | Integraciones          | ✅/🟡/🔴/⚪ |                           |       |
| §6  | Reglas de Negocio      | ✅/🟡/🔴/⚪ |                           |       |
| §7  | UI/UX                  | ✅/🟡/🔴/⚪ |                           |       |
| §8  | Infraestructura        | ✅/🟡/🔴/⚪ |                           |       |
| §9  | Branding               | ✅/🟡/🔴/⚪ |                           |       |
| §10 | Mobile/PWA             | ✅/🟡/🔴/⚪ |                           |       |
| §11 | Visual Direction Seeds | ✅/🟡/🔴/⚪ |                           |       |
```

| Estado | Significado                         |
| ------ | ----------------------------------- |
| ✅     | Suficiente y estable                |
| 🟡     | Parcial, requiere aclaración        |
| 🔴     | Faltante o inconsistente            |
| ⚪     | No aplica / diferido explícitamente |

---

## B. Gap Interview Rules

> Solo preguntar si hay alguna de estas condiciones:

1. Falta una decisión crítica
2. Hay contradicción entre fuentes
3. Algo tiene alto costo de reversión
4. El scope/timeline no puede evaluarse sin ese dato

### Límite de preguntas

| Situación                                 | Regla         |
| ----------------------------------------- | ------------- |
| Source package ya responde                | 0 preguntas   |
| Ambigüedad alta                           | 1-3 preguntas |
| Microaclaraciones cerradas del mismo tema | hasta 5       |
| Tema decidido en source principal         | 0 preguntas   |

### Pre-check obligatorio (ANTES de cada pregunta)

El agente **DEBE** verificar internamente:

- ¿Esto ya está resuelto en la fuente principal?
- ¿Esto es realmente necesario para el brief?
- ¿Estoy preguntando por **hueco real** o por **ritual de plantilla**?

### Para D0 (desde cero)

```markdown
"Vamos a entender tu proyecto.
Empecemos por lo más importante: ¿qué problema resuelve tu app y para quién?"
```

### Para D1 (con docs)

```markdown
"He procesado [N] documentos y tengo [X] decisiones firmes y [Y] gaps.
Voy a preguntarte solo por lo que no está claro. Aquí van las preguntas:"
```

---

_Phase 3 Complete → Continuar a Phase 4 (Synthesis Draft)_
