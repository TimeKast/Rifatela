# Phase 4: Synthesis Draft

> **Propósito:** Sintetizar un Discovery Brief sin drift, preservando source-of-truth.

---

## C. Synthesis Rules (Drift Guard)

> 🔴 **ANTES de escribir CADA sección, verificar contra el Freeze Map:**

Al redactar el brief:

- **Preservar** nombres propios, ownership, deadlines y milestones **verbatim**
- **No convertir** recomendaciones en decisiones firmes
- **No subir** items de future / no-MVP a MVP
- **No tratar** referencia legacy como source of truth
- **Marcar** inferencias explícitamente con confidence tags

### Drift Guard Checklist (MANDATORY)

```markdown
## Drift Guard

- [ ] No cambié stakeholder principal
- [ ] No reinterpreté deadlines o target dates
- [ ] No alteré el alcance MVP sin evidencia
- [ ] No convertí reference/legacy en source of truth
- [ ] No agregué decisiones nuevas como si fueran firmes
- [ ] No promoví recomendaciones a decisiones cerradas
```

**Si cualquiera falla → corregir antes de continuar.**

### Confidence Tags

| Tag            | Cuándo usar                               | En el brief                    |
| -------------- | ----------------------------------------- | ------------------------------ |
| _(sin tag)_    | Dato confirmado por source o usuario      | "Deadline: 17 de mayo 2026"    |
| `[INFERRED]`   | Deducción razonable de varias pistas      | "Se infiere [INFERRED] que..." |
| `[ASSUMPTION]` | Hipótesis de trabajo, no decisión cerrada | "[ASSUMPTION] Se asume que..." |
| `[OQ]`         | Info pendiente que requiere input         | "[OQ] ¿Cuál es el rate limit?" |

> Un `Confirmed` que en realidad es `Inferred` = **drift silencioso**.

---

## D. Source Document References

> 🔴 **OBLIGATORIO:** El brief DEBE incluir Source Package section.

```markdown
## 📦 Source Package

| #   | Documento | Clasificación | Key Decisions      | Ubicación                            |
| --- | --------- | ------------- | ------------------ | ------------------------------------ |
| 1   | [nombre]  | SoT           | [decisiones clave] | [path o "proporcionado por usuario"] |
```

> Los docs fuente se referencian para que fases downstream (/docs, /design, /backlog, /implement)
> puedan consultar el material original cuando necesiten más detalle.

---

## E. Decision Registry

> 🔴 **OBLIGATORIO:** El brief DEBE incluir Decision Registry.

```markdown
## 📋 Decision Registry

| #   | Decisión   | Tipo                      | Fuente | Evidencia    | Reversibilidad   | Sección |
| --- | ---------- | ------------------------- | ------ | ------------ | ---------------- | ------- |
| D1  | [decisión] | Firm / Open / Recommended | [doc]  | [cita o ref] | Low / Med / High | §X      |
```

---

## F. Reconciliation Checklist (Apéndice)

> 🔴 **ANTES de pasar a Phase 5, generar Reconciliation Checklist.**
> Es un APÉNDICE mecánico, no una sección de contenido.

Debe incluir al menos:

### F.1 Firm Decisions Registry

- stakeholder, deadline, MVP scope boundaries
- architectural constraints, non-goals

### F.2 Entities / Screens / Features Registry

- CADA entidad mencionada en prosa → cruzar con §4.1, §3.1, §7.2, §6
- CADA pantalla → cruzar con §7.2, entidades, roles
- CADA feature → cruzar con entidades, pantallas, reglas

### F.3 Open Questions & Assumptions Registry

- Preguntas vivas con impacto y owner
- Assumptions activas con categorización
- Contradicciones pendientes si existen

> 🔴 **La prosa es la fuente de verdad, la reconciliation es el índice verificable.**
> Si la prosa menciona una entidad en §3.1 pero Reconciliation no la lista → está incompleto.

---

## G. Stop Conditions

| Condición                                    | Severidad | Acción                        |
| -------------------------------------------- | --------- | ----------------------------- |
| No hay primary source en D1                  | P0        | 🛑 STOP                       |
| Contradicción material no resuelta           | P0        | 🛑 STOP o marcar OQ explícita |
| Drift detectado en ownership / dates / scope | P0        | 🛑 STOP                       |
| §1 / §2 / §3 / §6 en 🔴                      | P0        | 🛑 STOP                       |
| Brief bonito pero no trazable a fuentes      | P1        | Corregir                      |

---

_Phase 4 Complete → Continuar a Phase 5 (Challenge Pass)_
