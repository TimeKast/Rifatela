# Phase 6: Final Brief + Close

> **Propósito:** Generar artefactos finales y handoff.
> **Nota:** CHECKPOINT 2 ya fue aprobado en discovery.md antes de llegar aquí.

---

## Pre-requisitos

- ✅ CHECKPOINT 2 aprobado
- ✅ Source Fidelity Check: sin drift unauthorized
- ✅ Challenge Pass: sin blockers
- ✅ Coverage ≥ 80% en ✅ o ⚪
- ✅ 0 secciones críticas en 🔴 (§1, §2, §3, §6)

---

## Generar Artefactos

### 1. Crear Discovery Brief

```bash
mkdir -p ./docs/planning
# El agente genera el brief directamente, no copia template
```

### 2. Crear/Actualizar Project Config

```bash
cat ./docs/planning/project-config.md 2>/dev/null || echo "No project-config.md - crear desde template"
```

> 📝 **El project-config es metadata compacta del proyecto** para carga rápida en sesiones.
> Generarlo desde el template en `skills/roles/discovery/project-config.template.md`.
>
> **Secciones a rellenar desde el Brief:**
>
> - §1 Info y §2 Problem → Brief §1
> - §3 Stakeholders → Brief §2
> - §4 Stack → Brief §8 + SK actual
> - §5 Glossary → Brief §6 + terminología del dominio
> - §6 External Systems → Brief §8 (si hay microservicios/APIs)
> - §7 Integrations → Brief §8 (servicios cloud)

### 3. Verificar Placeholders

El agente DEBE verificar que NO quedaron placeholders:

```bash
grep -nE '\{\{[A-Z_]+\}\}|___|\[\.\.\.\]' docs/planning/00_DISCOVERY_BRIEF.md 2>/dev/null && echo "🔴 Placeholders encontrados" || echo "✅ Sin placeholders"
```

---

## SSOT Outputs

```
docs/planning/00_DISCOVERY_BRIEF.md  ← Brief completo con Source Package, Decision Registry, Confidence Tags
docs/planning/project-config.md      ← Config del proyecto (same data, different format)
```

---

## Handoff

```markdown
## ✅ Discovery Completado

**Proyecto:** [nombre]
**Stakeholder:** [nombre]

### 📊 Fidelity Score

| Métrica              | Valor                               |
| -------------------- | ----------------------------------- |
| Source Fidelity      | X%                                  |
| Traceability Density | X% decisions with source identified |
| Drift Items          | N (N unauthorized, N risky, N safe) |
| Assumptions          | N                                   |
| Open Questions       | N                                   |
| Coverage             | X/11                                |

### 📦 Artefactos

- `docs/planning/00_DISCOVERY_BRIEF.md`
- `docs/planning/project-config.md`

### 📋 Source Package

| Doc | Clasificación |
| --- | ------------- |

[lista de docs fuente para referencia downstream]

### 🤖 Challenge Pass

| Perspectiva     | Veredicto |
| --------------- | --------- |
| product-owner   | ✅/⚠️     |
| architect       | ✅/⚠️     |
| project-planner | ✅/⚠️     |

### ➡️ Próximo paso

`/proposal` para generar propuesta al cliente.
```

---

## Commit (Recommended Next Action)

> ⚠️ **Auto-commit solo si el usuario lo permite o el modo lo requiere.**
> Si hay Open Questions pesadas o assumptions de alto riesgo, considerar esperar antes de cristalizar.

**Sugerencia al usuario:**

```markdown
### 💾 ¿Commitear artefactos?

Los artefactos están listos. ¿Quieres que haga commit?

| OQs pendientes | Assumptions activas | Recomendación    |
| -------------- | ------------------- | ---------------- |
| N              | N                   | Commit / Esperar |
```

**Si el usuario confirma:**

// turbo

```bash
git add docs/planning/00_DISCOVERY_BRIEF.md docs/planning/project-config.md
git commit -m "docs(discovery): generate Discovery Brief

Source Fidelity: X% | Coverage: X/11 | Open Questions: N"
```

---

_Phase 6 Complete → Discovery terminado_
