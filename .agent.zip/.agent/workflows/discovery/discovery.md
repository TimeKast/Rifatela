---
description: Product discovery - preserve source of truth, identify gaps, interview only where needed, and generate a high-fidelity Discovery Brief
---

# /discovery — Product Discovery

> **Flujo:** Bootstrap (Fase 1 — Discovery)
> **Propósito:** Entender correctamente el proyecto y producir un Discovery Brief confiable para `/docs`.

---

## Principio Rector

El objetivo del workflow **NO es "llenar una plantilla".**
El objetivo es:

1. Preservar decisiones firmes del source package
2. Detectar huecos reales y contradicciones
3. Evitar drift sobre datos cerrados
4. Generar un brief usable downstream con alta fidelidad

---

## Hard Gates

| Validación                                    | Si falla                       |
| --------------------------------------------- | ------------------------------ |
| No hay fuente principal identificada en D1    | 🛑 STOP — Clasificar sources   |
| Hay contradicción material no resuelta        | 🛑 STOP — Resolver o marcar OQ |
| §1, §2, §3 o §6 quedan en 🔴 al cierre        | 🛑 STOP — Completar            |
| Se detecta drift en ownership / dates / scope | 🛑 STOP — Corregir             |
| Brief bonito pero no trazable a fuentes       | 🛑 STOP — Corregir             |

---

## 7 Fases

```
Phase 0: Mode Detection     → detectar modo y context status
Phase 1: Source Intake       → clasificar docs, cargar contexto
Phase 2: Freeze Map          → extraer decisiones firmes vs abiertas
Phase 3: Gap Interview       → preguntar SOLO lo no resuelto
Phase 4: Synthesis Draft     → brief con confidence tags
Phase 5: Challenge Pass      → multiagencia ANTES de cerrar
Phase 6: Final Brief         → reconciliation + fidelity check + cierre
```

---

## Phase 0: Mode Detection + Context Status

// turbo

```bash
cat ./.agent/workflows/discovery/phases/context.md
```

**Verificar si hay Brief:**

// turbo

```bash
ls docs/planning/00_DISCOVERY_BRIEF.md 2>/dev/null && echo "✅ Brief existe" || echo "❌ No hay Brief"
```

**Si NO existe → Saltar a Phase 1**

**Si SÍ existe → Mostrar opciones:**

```markdown
## 🔍 Discovery Mode

| #   | Modo            | Descripción                 |
| --- | --------------- | --------------------------- |
| 1   | **profundizar** | Mejorar el brief actual     |
| 2   | **revisar**     | Ver brief sin modificar     |
| 3   | **nuevo**       | Descartar y empezar de cero |

**¿Qué quieres hacer?** (1-3)
```

**ACTION:** Call `notify_user` con `BlockedOnUser: true`.

**Regla:** Si el usuario entrega un paquete documental sustancial, usar **D1** por defecto.

---

## Phase 1: Source Intake (Context Loading)

> Cargar contexto del kit, agent, y clasificar documentos fuente.

// turbo

```bash
cat ./.agent/workflows/discovery/phases/context-loading.md
```

---

## Phase 2: Freeze Map (Decision Extraction)

> Extraer decisiones firmes, abiertas, contradicciones. Construir Freeze Map.
> **Éste es el paso más importante del discovery.**

// turbo

```bash
cat ./.agent/workflows/discovery/phases/freeze-map.md
```

---

## 🛑 CHECKPOINT 1: Post-Intake Review

> ⚠️ **MANDATORY STOP — Después de Source Intake + Freeze Map**

**EL AGENTE DEBE:**

0. **Anunciar agents y skills activos (OBLIGATORIO, UNA VEZ):**

   ```
   🤖 @discovery-expert
   🧰 Skills: roles/discovery
   ```

1. Mostrar:
   - **Discovery mode** detectado (D0/D1/D2)
   - **Source Package:** Lista de docs procesados con clasificación
   - **Freeze Map Summary:**
     - Decisiones firmes: [N]
     - Decisiones abiertas: [N]
     - Contradicciones detectadas: [N]
     - Attachments procesados: [X/Y] (DEBE ser Y/Y)
   - **Coverage Map:** Estado actual de §1-§11
   - **Gap List:** Qué necesita preguntas
   - **Propuesta de siguiente paso:**
     - Generar draft directo (si coverage ya es alta)
     - Hacer pocas preguntas targeted
     - Profundizar discovery

2. Mostrar opciones:

   | #   | Opción      | Acción                                 |
   | --- | ----------- | -------------------------------------- |
   | 1   | continuar   | Proceder con Gap Interview + Synthesis |
   | 2   | profundizar | Revisar Freeze Map / más preguntas     |
   | 3   | cancelar    | Salir                                  |

3. **ACTION:** Call `notify_user` con `BlockedOnUser: true`, `ShouldAutoProceed: false`.

🛑 **STOP AQUÍ — NO continuar sin respuesta del usuario.**

---

## Post-Checkpoint Reconciliation (MANDATORY)

> 🔴 **Antes de empezar a redactar, reconciliar el feedback del checkpoint en el Freeze Map.**

Cada OQ tocada por el usuario durante el checkpoint DEBE reclasificarse como:

| Estado                        | Significado                                                          |
| ----------------------------- | -------------------------------------------------------------------- |
| **Resolved During Discovery** | El usuario la cerró explícitamente en esta conversación              |
| **Working Hypothesis**        | El usuario aceptó seguir provisionalmente con esa interpretación     |
| **Deferred**                  | Conscientemente se manda downstream (a /docs, /design, o /implement) |
| **Still Open**                | Sigue sin resolver — se mantiene como OQ                             |

> ⚠️ **"Inferred ok" NO se convierte automáticamente en Firm.** Default a Working Hypothesis
> a menos que el usuario lo cierre explícitamente como decisión.

---

## Phase 3: Gap Interview

> Preguntar SOLO por lo no resuelto. No entrevistar por costumbre.

// turbo

```bash
cat ./.agent/workflows/discovery/phases/gap-interview.md
```

---

## Phase 4: Synthesis Draft

> Generar Discovery Brief con Confidence Tags.

// turbo

```bash
cat ./.agent/workflows/discovery/phases/synthesis.md
```

**Todavía NO cerrar como final sin Challenge Pass.**

---

## Phase 5: Challenge Pass (Multi-Agent Review)

> 3 perspectivas revisan el brief ANTES de cerrarlo.

// turbo

```bash
cat ./.agent/workflows/discovery/phases/validation.md
```

---

## Phase 6: Final Brief + Close

> Aplicar correcciones, generar artefactos finales, cierre.

// turbo

```bash
cat ./.agent/workflows/discovery/phases/close.md
```

---

## 🛑 CHECKPOINT 2: Pre-Close Review

> 🔴 **HARD GATE — STOP ABSOLUTO antes de cerrar**

**EL AGENTE DEBE:**

1. Mostrar resultado de validaciones:
   - Source Fidelity: ✅/🔴
   - Drift Report: ✅/⚠️/🔴 (#items)
   - Internal Consistency: ✅/⚠️/🔴
   - Challenge Pass: ✅/⚠️/🔴 (3 perspectivas)
   - Structural Self-Check: ✅/🔴
   - Reconciliation: ✅/🔴
   - Coverage: X/11

2. Correcciones aplicadas: [lista o "ninguna"]

3. **Fidelity Score:**

   ```
   Source Fidelity: X% | Drift: N items | Assumptions: N | Open Questions: N | Coverage: X/11
   ```

4. Mostrar opciones:

   | #   | Opción     | Acción                         |
   | --- | ---------- | ------------------------------ |
   | 1   | cerrar     | Commit Brief + cerrar          |
   | 2   | corregir   | Aplicar correcciones           |
   | 3   | re-validar | Ejecutar validaciones de nuevo |

5. **ACTION:** Call `notify_user` con `BlockedOnUser: true`, `ShouldAutoProceed: false`

### Close Gate

Solo se puede cerrar si:

- Structural self-check OK
- Source fidelity OK (sin unauthorized drift)
- Drift report sin drift material
- Internal consistency aceptable
- Challenge pass sin blockers
- Open Questions visibles y honestos

🛑 **STOP — NO cerrar sin aprobación.**

---

## Shortcuts

```bash
/discovery D0    # Desde cero
/discovery D1    # Con docs existentes
/discovery D2    # Validar Brief existente
/discovery       # Pregunta el modo
```

---

## Flujo Completo

```
/start → /discovery → /proposal → /docs → /design → /backlog → /implement
```

---

_TimeKast Factory — Discovery Workflow (v3 — Refactored)_
