---
description: Comandos Git seguros para auto-run (turbo mode)
---

# /git — Safe Git Commands (Turbo Mode)

> Todos los comandos aquí son **seguros para auto-run**.

// turbo-all

---

## Read-Only

```bash
git status
git log -n 10
git log --oneline -20
git diff
git diff --stat
git diff --cached
git branch
git branch -a
git remote -v
git show
git fetch
git fetch --all
```

## Stage & Commit

```bash
git add -A
git add .
git commit -m "message"
```

## Pull & Push

```bash
git pull
git pull origin develop
git push
git push origin develop
```

---

## ⛔ NUNCA auto-run

> Estos comandos **requieren confirmación explícita**:

- `git reset --hard` (pérdida de datos)
- `git push --force` (reescribe historial)
- `git push origin main` (ver regla 04_complementary §7b)
- `git merge ... main` (ver regla 04_complementary §7b)
- `git clean -fd` (elimina archivos)
- `git rebase` (reescribe historial)
- `git stash drop` (pérdida de datos)
- `git branch -D` (elimina branches)

---

_Factory Workflow — Safe Git Commands_
