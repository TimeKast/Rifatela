---
description: Comandos de desarrollo y auditoría seguros para auto-run (turbo mode)
---

# /dev — Safe Commands (Turbo Mode)

> Todos los comandos aquí son **seguros para auto-run**.
> Cross-platform: macOS + Windows (PowerShell).

// turbo-all

---

## Build & Verify

```bash
pnpm build
pnpm typecheck
pnpm lint
pnpm format:check
pnpm test
```

## Dev Server

```bash
pnpm dev
```

## Linting & Formatting

```bash
pnpm lint:fix
pnpm format
```

## Dependencies (read-only)

```bash
pnpm list
pnpm outdated
pnpm audit
```

## DB (read-only)

```bash
pnpm db:studio
```

---

## ⛔ NUNCA auto-run

> Estos comandos **requieren confirmación explícita**:

- `pnpm install` / `pnpm add` (modifica deps)
- `pnpm db:push` / `pnpm db:migrate` (modifica DB)
- `rm -rf` / `Remove-Item -Recurse` (elimina archivos)
- Cualquier comando con `--force` o `-f`

---

_Factory Workflow — Safe Dev Commands_
